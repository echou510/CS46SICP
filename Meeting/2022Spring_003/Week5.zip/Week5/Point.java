class Point {
    int x;
    int y;

    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public static int add(int x, int y) {
        return 0;
    }

    public static double add(double x, double y) {
        return 0.0;
    }

    public static void main(String[] args) {
        var a = 3;
        var b = "string";

    }
}