
public class Local
{
    public static void main(String[] args){
      System.out.print("\f");
      var a =3; 
      var b = 4.0; 
      var c = a + b; 
      System.out.println(c); 
      var d = "Abcde"; 
      var e = d + c; 
      System.out.println(e); 
    }
}
