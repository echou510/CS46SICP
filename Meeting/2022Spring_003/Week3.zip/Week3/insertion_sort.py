import random
def isort(seq): 
    for i in range(1, len(seq)):  # i is the to be inserted 
        j = i - 1
        x = seq[i]
        while j>=0 and seq[j]>=x: 
            seq[j+1] = seq[j]
            j-= 1    
        j += 1
        seq[j] = x

N = 100000
a = [random.randint(0, N) for i in range(N)]

print("Before Sorting: ", a)
isort(a)
print("After Sorting: ", a)