from pylab import *   # pylab = numpy + matplotlib 
#from matplotlib.pyplot import *
import numpy as np 
import random 
a = np.linspace(0, 1000, 1001)
b = [2*t for t in a]
# b = [random.randint(0, 10000) for t in a]

figure()
loglog(a, b, 'b')
show()