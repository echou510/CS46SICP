import time
import random
a = [random.randint(0, 100000) for t in range(5)]
b = [x for x in a]
c = [x for x in a]

def selection(a): 
    for i in range(len(a)-1):  # i is the to be swapped location
        m = a[i]
        midx = i
        for j in range(i, len(a)): 
            if a[j]<m: 
                m = a[j]
                midx = j
        a[i], a[midx] = a[midx], a[i]
    return a

start = time.time()
a = selection(a)
end = time.time()
print(end - start)

print(a)
print(b)
print(c)
