def max(alist):
    if len(alist)==0: return 0
    m = alist[0]
    for x in alist: 
        if x>m: m = x
    return m

def max2(*argv): 
    if len(argv)==0: return 0
    m = argv[0]
    for x in argv: 
        if x>m: m = x
    return m

def makedict(**karg): 
    print(karg)

print(max([5, 4, 2, 10, 1])) 
print(max2(5, 4, 2, 10, 1)) 

makedict(a=1, b=2, c=3)