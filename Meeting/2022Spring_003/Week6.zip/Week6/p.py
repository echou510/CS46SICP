class p: 
    def __init__(self, *argv): 
        self.list = argv
    
    def __str__(self): 
        s = "["
        for i in range(len(self.list)): 
            if i==0: s += str(self.list[i])
            else: s+= "," + str(self.list[i])
        s += "]"
        return s



p1 = p(1, 2, 3)

print(p1)