from pylab import * 
import numpy as np 

x = np.logspace(1, 5, num=5, base=10)  # 10 is 1E1
y = [2*t for t in x]

print("x[]=", x)
print("y[]=", y)

# linear-linear plot
fig = figure()
plot(x, y, 'b')
show()

# log-log plot
fig1 = figure()
loglog(x, y, 'g')
show()

# linear-log
fig2 = figure()
ax = fig2.gca()
ax.set_yscale('log')
ax.plot(x, y, 'r')
show()