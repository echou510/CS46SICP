from pylab import * 
import numpy as np 

x = np.linspace(0, 100, 101)
y = [2*t for t in x]

figure()
plot(x, y, 'b')
show()