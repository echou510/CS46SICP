tokens_list = [":=", "(", ")", "+", "-"]
def replace_tokens(s): 
    for t in tokens_list: 
        s = s.replace(t, " "+t+" ")
    return s

f = open("a.cal", 'r')
fstr = f.read().strip() 
print("Before: ", fstr)
fstr = replace_tokens(fstr)
print("After: ", fstr)

tokens = fstr.split()
print(tokens)

f.close() 