f = open("a.cal", 'r')
fstr = f.read().strip() 
pos = fstr.find(":=")
while (pos>=0): 
    print(pos)
    pos = fstr.find(":=", pos+1)
f.close() 