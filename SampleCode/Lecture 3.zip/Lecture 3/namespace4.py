def f(b): 
    a = 6 
    print(dir())
    print(f.__dict__)
    return a*b

a = 0
print(dir())
print('f(3)= ', f(3))
print('a=', a)