def mul(x): 
    def g(y): 
        return x*y
    return g

print(mul(2)(3))


