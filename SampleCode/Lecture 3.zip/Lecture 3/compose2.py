def happy(text):
	return ":)" + text + ":)"
def sad(text):
	return ":(" + text + ":("
def make_texter(emoji):
	def texter(text):
		return emoji + text + emoji
	return texter
def composer(f, g):
	def composed(x):
		return f(g(x))
	return composed

msg1 = composer(happy, make_texter("&"))(" Snow Day! ")
print(msg1)

