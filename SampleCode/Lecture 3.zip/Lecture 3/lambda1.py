print("Lambda Function as Callable: ")
print((lambda x: x*x)(2))

cube = lambda x: x**3
print("Lambda Function as Short Function Definition: ")
print(cube(2))

a = [(3, 1), (5, 6), (4, -1), (8, 2)]
a.sort(key=lambda t: t[1])
print("Lambda Function as a key: ")
print(a)