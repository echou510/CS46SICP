def thingy(x, y): 
    return bobber(y)

def bobber(a): 
    return a+y

result = thingy("ma", "jig")
print(result)