sum = 2
sum_of_squares = 0

def accumulate(x): 
    global sum, sum_of_squares
    sum += x
    sum_of_squares += x * x

accumulate(sum)
print('sum = ', sum)
print('sum_of_squares= ', sum_of_squares)