def f(b): 
    a = 6 
    return a*b

a = 0
print('f(3)= ', f(3))
print('a=', a)