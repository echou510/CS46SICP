class Int_func: 
    def __init__(self, x): 
        self.x = x
    def __call__(self, y): 
        return self.x + y 

plus2 = Int_func(2)
print(plus2(3))
