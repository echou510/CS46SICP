def g(n): 
    print('Start g')
    n += 1
    print('n = ', n)

def f(n): 
    print('Start f')
    n += 1
    print('n= ', n)
    g(n)

n = 1 
print("Outside a function, n= ", n)
f(n)