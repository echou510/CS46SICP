def add(x, y): 
    return x + y

def sub(x, y): 
    return x - y

def go(x, y, f): 
    return f(x, y)

print(go(2, 3, add))
print(go(2, 3, sub))
print(go(2, 3, lambda a, b: a*b))
