from operator import add 
def make_adder(n):
  return lambda x: n + x

msg1 = make_adder(2)(3)
print("make_adder by composite function: ", msg1)

def curry2(f):
	def g(x):
		def h(y):
			return f(x, y)
		return h
	return g

make_adder = curry2(add)
msg2 = make_adder(2)(3)
print("make_adder by currying: ", msg2)

curry2 = lambda f: lambda x: lambda y: f(x, y)
make_adder = curry2(add)
msg3 = make_adder(2)(3)
print("make_adder by lambda currying: ", msg3)