numbers = [1, 2, 3, 4, 5]
x = list(map(str, numbers))
print(x)

def custom_map(function, iterable):
    from functools import reduce

    return reduce(
        lambda items, value: items + [function(value)],
        iterable,
        [],
    )

x = list(custom_map(str, numbers))
print(x)