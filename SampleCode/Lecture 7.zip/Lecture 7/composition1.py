def inner():
    print("I am function inner()!")

def outer(function):
    function()

outer(inner)