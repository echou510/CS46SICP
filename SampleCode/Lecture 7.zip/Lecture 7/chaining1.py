def outer():
    def inner():
            print("I am function inner()!")

    # Function outer() returns function inner()
    return inner

function = outer()
function
function()
outer()()