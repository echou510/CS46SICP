numbers = list(range(10))
print(numbers)

def is_even(x):
    return x % 2 == 0

x = list(filter(is_even, numbers))
print(x)

def custom_filter(function, iterable):
    from functools import reduce

    return reduce(
        lambda items, value: items + [value] if function(value) else items,
        iterable,
        []
    )

x = list(custom_filter(is_even, numbers))
print(x)