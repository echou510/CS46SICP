def func():
    print("I am function func()!")

func()

another_name = func
another_name()
