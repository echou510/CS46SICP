def multiply(x, y):
    return x * y

def factorial(n):
    from functools import reduce
    return reduce(multiply, range(1, n + 1))

print(factorial(4))  # 1 * 2 * 3 * 4
print(factorial(6))  # 1 * 2 * 3 * 4 * 5 * 6