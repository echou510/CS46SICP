def gcd1(m, n): 
    if n==0: return m
    return gcd1(n, m%n)

def gcd2(m, n): 
    if (m==n): return m
    if (m>n): return gcd2(m-n, n)
    return gcd2(m, n-m)

print(gcd1(48, 36))
print(gcd2(48, 36))
print(gcd1(36, 48))
print(gcd2(36, 48))