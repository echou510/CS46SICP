numbers = [1, 2, 3, 4, 5, 6]
a = (x*x for x in numbers)
b = [x*x for x in numbers]
c = {x*x for x in numbers}
d = {x:x*x for x in numbers}
print(a)
print(b)
print(c)
print(d)