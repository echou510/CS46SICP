def func(a=0, b=0, *args) -> int:
    y = 0
    for x in args: 
        y += a * x + b
    return y

print(func(1, 1, 1, 2, 1))
