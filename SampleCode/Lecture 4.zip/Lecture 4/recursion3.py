def fib(n): 
    if n==0 or n==1: return 1
    return fib(n-1)+fib(n-2)

def fib2(n):
    if n==0 or n==1: return 1
    i = 2; f = 1; f1 = 1; f2 = 1
    while i<=n: 
        f = f1 + f2 
        i += 1
        f2 = f1
        f1 = f 
    return f 
for i in range(1, 6): 
    print("fib(%d)=%d" % (i, fib(i)))
for i in range(1, 6): 
    print("fib2(%d)=%d" % (i, fib2(i)))
    