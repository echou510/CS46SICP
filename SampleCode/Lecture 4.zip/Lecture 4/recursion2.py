def gcd3(m, n):
    while (m!=n):
        if (m>n): m = m-n
        else: n = n-m
    return m

def gcd4(m, n):
    while n!=0 and m!=0:
        if m>n: m = m%n
        else: n = n%m
    return n if m==0 else m  

print(gcd3(48, 36))
print(gcd4(48, 36))
print(gcd3(36, 48))
print(gcd4(36, 48))