from itertools import count
counter = count(start=13)
print((counter))
print(next(counter))
print(next(counter))