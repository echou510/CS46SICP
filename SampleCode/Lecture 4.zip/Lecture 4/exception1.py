x = 0
done = False
while not done: 
    try:
        x = int(input("Enter an even number: "))
        if x%2 !=0: raise BaseException("Not Even")
        done = True
    except BaseException as e:
        print(e)
    except:   
        print("Wrong Input Format")
