def plus(n, x):
    return  n+x 

def f(func):   # function as input vector as output 
    def g(n): 
        def h(x): 
            return func(n, x)
        return h
    return g 

add2 = f(plus)(2)   # make a plus2 function 
print(add2(3))

makeplus = lambda func: lambda n: lambda x: func(n, x)
plus2 = makeplus(plus)(2)
print(plus2(3))

class h: 
    def __init__(self, func, n): 
        self.func = func
        self.n = n 
    def __call__(self, x): 
        return self.func(self.n, x)

increase2 =  h(plus, 2)
print(increase2(3))
