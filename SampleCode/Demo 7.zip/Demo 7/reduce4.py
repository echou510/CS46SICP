import functools as fn
def connect(a, b): 
    return a+b

s = "aeiou"
slist = list(s)
data = fn.reduce(connect, slist)
print(data)

a = [1, 2, 3, 4, 5]
data2 = fn.reduce(connect, a)
print(data2)