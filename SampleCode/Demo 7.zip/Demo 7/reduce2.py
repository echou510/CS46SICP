def h(func):
    r = 0
    def f(func, s): 
        def g(x):
            nonlocal r 
            r = s + x 
            return f(func, s+x)
        return g
    connect = f(plus, 0)
    x = connect(1)(2)(3)(4)(5)
    return r 

def plus(a, b): 
    return a + b 

print(h(plus))