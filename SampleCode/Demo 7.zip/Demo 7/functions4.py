def plus(n, x): 
    return n + x 

def f(func, n, x): 
    return func(n, x)

def plusX(func, x): 
    return f(plus, 2, x)

def plus2(x): 
    return plusX(plus, x)

print(plus2(3))

