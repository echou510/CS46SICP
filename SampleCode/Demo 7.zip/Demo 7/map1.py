def plus2(x):
    return 2+x 

x = [1, 2, 3]
y = list(map(plus2, x))

print(x)
print(y)