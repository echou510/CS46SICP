def f(x):    # normal function
    return x**2 

g = lambda x: x*x   # anonymous function, lambda expression

class h:  # callable object, function closure
    def __call__(self, x): 
        return x*x

print(f(4))
print(g(4))
h1 = h()
print(h1(4))

print(callable(f))
print(callable(g))
print(callable(h1))