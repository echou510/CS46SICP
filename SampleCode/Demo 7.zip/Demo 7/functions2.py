def f(n):    # function factory 
    def g(x): 
        return n+x 
    return g

add2 = f(2)  # g(x): 2 + x
print(add2(3))

g = lambda n: lambda x: n+x
plus2 = g(2)
print(plus2(3))

class h: 
    def __init__(self, n): 
        self.n = n 
    def __call__(self, x): 
        return self.n + x

increase2 = h(2)
print(increase2(3))