import functools as fn 
s = "In computer science, functional programming is a programming paradigm where programs are constructed by applying and composing functions. ... This allows programs to be written in a declarative and composable style, where small functions are combined in a modular manner." 
slist = list(s)
def plus(a, b): 
    return a + b
sx = fn.reduce(plus, slist)
print(sx)