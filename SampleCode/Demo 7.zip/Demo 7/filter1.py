s = "In computer science, functional programming is a programming paradigm where programs are constructed by applying and composing functions. ... This allows programs to be written in a declarative and composable style, where small functions are combined in a modular manner." 
def alpha(c): 
    return c.isalpha()
slist = list(s)
sx = "".join(list(filter(alpha, slist)))
print(sx)