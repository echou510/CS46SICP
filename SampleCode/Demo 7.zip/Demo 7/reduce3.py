def plus(a, b): 
    return a + b 

r = 0 
def f(func, s): 
    def g(x):
        global r 
        r = s + x
        print(s+x)
        return f(func, s+x)
    return g
connect = f(plus, 0)
x = connect(1)(2)(3)(4)(5)

print(r)
