import numpy as np 

a = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 0]) 
result = np.any(3 in a)
print(result)
result = np.any(a > 5)
print(result)