from pylab import * 
import numpy as np 

x = np.linspace(0, 10, 11)
y = list(map(lambda x: x**2, x))

figure()
plot(x, y, 'b')
show()