public class Point {
    int x = 0;
    int y = 0;

    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int get() {
        return x;
    }

    public int get(int t) {
        y = t + y;
        return y;
    }

    public String toString() {
        return "(" + x + "," + y + ")";
    }

    public static void main(String[] args) {
        Point p = new Point(0, 0);
        Point q = p;
        System.out.println(p.get());
        System.out.println(p.get(2));
    }
}