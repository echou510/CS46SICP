#import builtins as bltin
#from builtins import *

def sum(tt):
    return tt[1]-tt[0]

a = 3 
b = 4 
t = (a, b)
from personal import * 
c = sum(t)
print(c)