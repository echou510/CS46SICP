from pylab import * 
import numpy as np 
def curryIt(f): 
    def param(freq): 
        def h(angle): 
            return f(freq*angle)
        return h
    return param
 
sin2f = curryIt(np.sin)(2)    # sin(2 * theta)

x = np.linspace(0, 6.28, 101)
y = [sin2f(t) for t in x]

figure()
plot(x, y, 'b')
show()