def f(b): 
    return a * b

print("f(3)=", f(3))  # a not defined at this moment. 
a = 0 
print('a= ', a)


