def f(x): 
    def g(y): 
        nonlocal x 
        x = 1
        print("x in g: ", x)
    g(1)
    x -= 1 
    print("x in f: ", x)

f(3)