import personal 
import sys
def f(): 
    b = 4 
    print(f.__dict__)

print(dir()) # what are the modules (namespaces) that you have at run-time

a = 4
print(globals())
f() 

f.__dict__["b"] = 10 

print(f.__dict__)
