# G: Global 
a = 3

def f(): 
    # L: Local 
    global a
    print("a if f(): ", a)
    if True:  
        a = 100
        print("a in enclosed: ", a)
    print("a if f() 2nd: ", a)

f()

print("global a: ", a)