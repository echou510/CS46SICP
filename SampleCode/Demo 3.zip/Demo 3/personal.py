def sum(t):
    return t[0]*t[1] 