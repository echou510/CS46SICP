def double(y): 
    x = 2
    y *= x
    print("Inside x=%d, y=%d" % (x, y))

x, y = 3, 4 
print("Outside x=%d, y=%d" % (x, y))
double(y)
print("Outside x=%d, y=%d" % (x, y))