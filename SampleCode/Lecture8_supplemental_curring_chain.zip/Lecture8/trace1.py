def trace1(f):
    def traced(x):
        print("->", x)
        r = f(x)
        print("<-", r)
        return r
    return traced

@trace1
def square(x):
    return x * x
print(square(3))
