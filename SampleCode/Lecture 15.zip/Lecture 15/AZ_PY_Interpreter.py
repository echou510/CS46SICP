class AZ_PY_Interpreter:
    def __init__(self):
        self.stack = []
    def LOAD_FAST(self,number):
        self.stack.append(number)
    def PRINT_VALUE(self):
        answer = self.stack.pop()
        print(answer)
    def BINARY_ADD(self):
        first_num = self.stack.pop()
        second_num = self.stack.pop()
        total = first_num + second_num
        self.stack.append(total)
    def run_code(self, what_to_execute):
        instructions = what_to_execute["instructions"]
        numbers = what_to_execute["numbers"]
        for each_step in instructions:
            instruction, argument = each_step
            if instruction == "LOAD_FAST":
                number = numbers[argument]
                self.LOAD_FAST(number)
            elif instruction == "BINARY_ADD":
                self.BINARY_ADD()
            elif instruction == "PRINT_VALUE":
                self.PRINT_VALUE()

execution_bytecode = {
    "instructions": [("LOAD_FAST", 0),  # the first number
                     ("LOAD_FAST", 1),  # the second number
                     ("BINARY_ADD", None),
                     ("RETURN_VALUE",None),
                     ("PRINT_VALUE", None)],
    "numbers": [5, 7]
}
my_python = AZ_PY_Interpreter()
my_python.run_code(execution_bytecode)