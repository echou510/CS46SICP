DEBUG_MODE = False
TYPE   = {
    "div": 'DIV', 
    "lparen": 'LPAREN', 
    "rparen": 'RPAREN', 
    "plus": 'PLUS', 
    "minus": 'MINUS',
    "times": 'TIMES',
    "assign": 'ASSIGN',
    "number": 'NUM',
    "id": "ID"
}

def report(message):
    print(message) 

def terminate_with(tokens, tokens_type, token, ttype): 
    tokens.append(token)
    tokens_type.append(TYPE[ttype])

def main(): 
    filename = input("Enter a file: ")
    f = None 
    try: 
        f = open(filename, "r")
    except: 
        print("Input File Not Found. ")

    fstr = f.read().strip() # clean up eof 
    state = 1
    tokens = []
    tokens_type = []
    token = ""

    for i in range(len(fstr)):
        ch = fstr[i]
        if DEBUG_MODE: print("Processing...", "(state=%d, ch=\'%s\')"% (state, ch))
        if (state, ch)==(1, '/'):  
            token += ch
            if i!=len(fstr)-1: 
                if fstr[i+1] in '/*': # look ahead
                    state = 2
                    continue
                else: # div 
                    terminate_with(tokens, tokens_type, token, 'div')
                    state =1
                    token=""
                    continue
            else: 
                report("E1: / symbol at the end of line error!")
                return
        elif (state, ch)==(1, '('):  # (
            token += ch
            terminate_with(tokens, tokens_type, token, 'lparen')
            state = 1
            token = ""
            continue
        elif (state, ch)==(1, ')'):  # )
            token += ch
            terminate_with(tokens, tokens_type, token, 'rparen')
            state = 1
            token = ""
            continue
        elif (state, ch)==(1, '+'):  # +
            token += ch
            terminate_with(tokens, tokens_type, token, 'plus')
            state = 1
            token = ""
            continue
        elif (state, ch)==(1, '-'):  # - 
            token += ch
            terminate_with(tokens, tokens_type, token, 'minus')
            state = 1
            token = ""
            continue
        elif (state, ch)==(1, '*'):  # * 
            token += ch
            terminate_with(tokens, tokens_type, token, 'times')
            state = 1
            token = ""
            continue
        elif (state, ch)==(1, ':'): 
            token += ch 
            state = 11
            continue
        elif (state, ch)==(11, '='): 
            token += ch
            terminate_with(tokens, tokens_type, token, 'assign')
            state = 1
            token = ""
            continue
        elif state==11: 
            report("E2: : not followed by = error")
            return
        elif state==1 and (ch==" " or ch=="\t" or ch=="\n"): 
            token = ""
            state = 1
            continue
        elif (state, ch)==(2, '/'):
            token=""
            state = 3
            continue
        elif (state, ch)==(2, '*'): 
            token=""
            state = 4
            continue
        elif (state, ch)==(3, '\n'): 
            token=""
            state = 1
            continue
        elif state==3:
            token=""
            continue
        elif (state, ch)==(4, '*'): 
            token=""
            state = 5
            continue
        elif state==4: 
            token=""
            continue
        elif (state, ch)==(5, '/'):
            token=""
            state = 1
            continue
        elif (state, ch)==(5, '*'): 
            continue
        elif state==5:
            token=""
            state = 4
            continue
        elif (state, ch)==(1, '.'): 
            token=""
            state = 13
            continue
        elif state==13 and ch.isdigit(): 
            token += ch
            state = 15
            continue
        elif state==13:
            report("E4: Number Format Error") 
            return
        elif state==1 and ch.isdigit(): 
            token += ch
            if i==len(fstr)-1 or not fstr[i+1].isdigit(): 
                terminate_with(tokens, tokens_type, token, 'number')
                state = 1
                token=""
            else:    
                state = 14
            continue
        elif state==14:
            if ch.isdigit(): 
                token += ch
                if i==len(fstr)-1 or not fstr[i+1].isdigit(): 
                    terminate_with(tokens, tokens_type, token, 'number')
                    state = 1
                    token=""
                else:    
                    state = 14
                continue
            if ch=='.':
                token += ch
                state = 15
                continue
            else: 
                report("E3: : number format error")
        elif state==15:
            token += ch
            if i==len(fstr)-1 or not fstr[i+1].isdigit(): 
                terminate_with(tokens, tokens_type, token, 'number')
                state = 1
                token=""
            else:    
                state = 15
            continue
        elif state==1 and ch.isalpha(): 
            token += ch
            if i==len(fstr)-1 or not (fstr[i+1].isalpha() or fstr[i+1].isdigit()):  
                terminate_with(tokens, tokens_type, token, 'id')
                state = 1
                token=""
                continue
            state = 16
            continue
        elif state==16 and (ch.isalpha() or ch.isdigit()): 
            token += ch
            if i==len(fstr)-1 or not (fstr[i+1].isalpha() or fstr[i+1].isdigit()):  
                terminate_with(tokens, tokens_type, token, 'id')
                state = 1
                token=""
            continue
        elif state==16: 
            state = 1
            token=""
            continue

    print(tokens)
    print(tokens_type)

if __name__ == "__main__": 
    main()