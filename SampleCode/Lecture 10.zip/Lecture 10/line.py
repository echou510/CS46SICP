f = open("text.txt", "r")
line = f.readline()
tokens=[]
while line: 
    line = line.strip()
    tokens += line.split()
    line = f.readline()
print(tokens)
f.close()
