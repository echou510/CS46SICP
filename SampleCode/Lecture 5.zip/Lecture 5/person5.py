class Person1:
    pets = []

    def add_pet(self, pet):
        self.pets.append(pet)

def main1():
    jane = Person1()
    bob = Person1()
    jane.add_pet("cat")
    print(jane.pets)
    print(bob.pets) # oops!

class Person2:

    def __init__(self):
        self.pets = []
    def add_pet(self, pet):
        self.pets.append(pet)

def main2():
    jane = Person2()
    bob = Person2()

    jane.add_pet("cat")
    print(jane.pets)
    print(bob.pets)

def main():
    print("Using Class Variable for pets list...")
    main1()
    print("Using Instance Variable for pets list...")
    main2()

if __name__ == "__main__":
    main()