a = [0]
a.append(3)

print(a)

a.append(4)
print(a)

a.append(0)
a.append(0)
a.remove(0)  # remove the first occurrence of 0
print(a)
a.remove(0)
print(a)
b = [0] * 100    # equivalent to  int[] b = new int[100]; in Java
c = [ [0]*9 ] * 9    # equivalent to int[][] c = new int[9][9]; in Java

for i in range(len(c)):             # equivanelent to  for (int i=0; i< c.length; i++)
    str = ""
    for j in range(len(c[0])):      # equivalent   to       for (int j=0; j< c[0].length; j++)
        c[i][j] = (i+1) * (j+1)
        str += "%3d " % c[i][j]
    print(str)

# List can be used as record, struct or object in C/C++, or Java language
#  d[0]:  int age
#  d[1]:  int id;
#  d[2]:  boolean male;
d = [1, "A3003", True]
print(d)

# dictionary
e = {'age': 1, 'id': "A3003", 'male': True }  # dictionary (map in other language)
                                              # {key: value, key: value, key:value}
print(e['age'])
print(e['id'])
print(e['male'])

f = {0:1, 1:2, 2:4}    # same as f = [1, 2, 4]
print(f[0])
print(f[1])
print(f[2])

print(2 in a)  # check in a contains 2

