class Person:
    def __init__(self, name, surname):
        self.name = name
        self.surname = surname

    def fullname(self):
        return "%s %s" % (self.name, self.surname)

def main():
    jane = Person("Jane", "Smith")
    print(dir(jane))  # listing of properties

if __name__ == "__main__":
    main()