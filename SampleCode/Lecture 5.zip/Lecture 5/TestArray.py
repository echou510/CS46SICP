array = [0] * 20

for i in range(len(array)):
    array[i] = i
    print(array[i])

"""
int[] array = new int[20]; 
for (int i=0; i<20; i++){
   System.out.println(i); 
}
"""