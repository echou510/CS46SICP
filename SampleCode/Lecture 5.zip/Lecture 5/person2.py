import datetime # we will use this for date objects

class Person:
    def __init__(self, name, surname, birthdate, address, telephone, email):
        self.name = name
        self.surname = surname
        self.birthdate = birthdate
        self.address = address
        self.telephone = telephone
        self.email = email

    def age(self):
        if hasattr(self, "_age"):  # hasattr check if the attribute exist).
            return self._age

        today = datetime.date.today()
        age = today.year - self.birthdate.year
        if today < datetime.date(today.year, self.birthdate.month, self.birthdate.day):
            age -= 1
        self._age = age
        return age

def main():
    person = Person("Jane", "Doe",
    datetime.date(1992, 3, 12),
    "No. 12 Short Street, Greenville",
    "555 456 0987",
    "jane.doe@example.com"
    )

    print(person.name)
    print(person.email)
    print(person.age())
    print("\n")
    person.pets = ['cat', 'cat', 'dog']
    print(person.pets)
    print(hasattr(person, "pets"))  # the attribute name to be check needs to be a string
    print(getattr(person, "pets"))
    print("person.age() call=%d\n" % person.age())  # using age() to access private data field _age
    print("person._age =%d\n" % person._age)        # not really private data field
    print("\n")

if __name__ == "__main__":
    main()
