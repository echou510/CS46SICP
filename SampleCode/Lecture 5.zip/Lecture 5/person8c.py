class Person:
    def __init__(self, name, surname):
        self.name = name
        self.surname = surname

    @property
    def fullname(self):
        return "%s %s" % (self.name, self.surname)

    @fullname.setter
    def fullname(self, value):
        # this is much more complicated in real life
        name, surname = value.split(" ", 1)
        self.name = name
        self.surname = surname

    @fullname.deleter
    def fullname(self):
        del self.name
        del self.surname

def main():
    print("Fully decorated version")
    jane = Person("Jane", "Smith")
    print("Jane's fulle name when constructed ="+jane.fullname)
    jane.fullname = "Jane Doe"
    print("Jane's full name after LHS setter  ="+jane.fullname)
    print("Jane's name after LHS setter       ="+jane.name)
    print("Jane's surname after LHS setter    ="+jane.surname)

if __name__ == "__main__":
    main()

