class Free:
    pass

def setName(a, y):
    a.name = y

f0 = Free()
f0.name = "Christina"
print(f0.name)

setName(f0, "Eric Chou")
print(f0.name)

class Free1:
    pass

f1 =Free1()
f1.age = 32
f1.name = "Eric Chou Jr"
print(f1.name)
f1.setName = setName
f1.setName(f1, "Chris")
print(f1.name)

print(f1.age)

class Free2:
    pass

f2 = Free2()
f2.setN = setName
f2.setN(f2, "KKK")
print(f2.name)