class Base:
    attr = "class attribute"
    def static_method():
        print("static method written inside class")
    def class_method(cls):
        print("class method written inside class")
        print(cls.attr)
    #Using staticmethod builtin function
    static_method = staticmethod(static_method)
    #Using classmethod builtin function
    class_method = classmethod(class_method)

print("\nCreate a Base object")
b = Base()
print("\nb instance call static_method()")
b.static_method()
# It should print "static method written inside class"
print("\nBase class call static_method")
Base.static_method()
# It should print "static method written inside class"
print("\nb instance call class_method")
b.class_method()
# It should print "class method written inside class" and "class attribute"
print("\nBase class call class_method")
Base.class_method()
#It should print "class method written inside class" and "class attribute"