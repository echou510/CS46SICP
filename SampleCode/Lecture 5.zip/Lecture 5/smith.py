class Smith:
    surname = "Smith"
    profession = "smith"

    def __init__(self, name, profession=None):
        self.name = name
        if profession is not None:
            self.profession = profession

def main():
    print(Smith.surname)
    print(Smith.profession)
    sm = Smith("Eric", "eric")
    print("Name="+sm.name)                    # instance variable
    print("Surname="+sm.surname)              # class varibale default value
    print("Profession="+sm.profession)        # instance variable overriding class variable

if __name__ == "__main__":
    main()


