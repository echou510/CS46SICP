class Person:
    def __init__(self, height):
        self.height = height

    def get_height(self):
        return self.height

    def set_height(self, height):
        self.height = height

def main():
    print("Undecorated property version")
    jane = Person(153) # Jane is 153cm tall
    print("When constructed=%d" % jane.get_height())
    jane.height += 1 # Jane grows by a centimetre
    print("After Increment =%d" % jane.get_height())
    jane.set_height(jane.height + 1) # Jane grows again
    print("After setter    =%d" % jane.get_height())

if __name__ == "__main__":
    main()

