# Defining a class
class Music4:
    # Creating a constructor
    def __init__(self):
        # These are private attributes
        self.__genre = "Pop"
        self.__singer = "Coldplay"
        # This is a public attribute
        self.releaseyear = 2000
    # Creating a function
    def foo(self):
        print("Song: Trouble")

# Creating object of the class
obj = Music4()
# Calling the method inside the class
obj.foo()
# Accessing the private members outside the class using name mangling
print("Genre:", obj._Music4__genre)
print("Singer:", obj._Music4__singer)
# Accessing the public member normally
print("Year of release:", obj.releaseyear)