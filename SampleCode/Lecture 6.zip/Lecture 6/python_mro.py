# python 3 MRO D-B-C-A
# swtich betwen pasa snd the functional definition to observe the MRO
class A:
    def who_am_i(self):
        print("I am a A")
class B(A):
    pass
    #def who_am_i(self):
    #    print("I am a B")
class C(A):
    pass
    #def who_am_i(self):
    #    print("I am a C")
class D(B,C):
    pass
    #def who_am_i(self):
    #    print("I am a D")
print("Run-A")
d1 = D()
d1.who_am_i()


