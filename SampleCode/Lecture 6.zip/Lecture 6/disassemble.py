import dis 
x = [1, 2, 3] 
dis.dis('for _ in x: pass') 
