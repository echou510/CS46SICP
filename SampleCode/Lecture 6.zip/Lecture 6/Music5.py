# Defining a class
class Music5:
    def __init__(self):
        self._song = 'Trouble'

    @property
    def foo(self):
        return self._song

    @foo.setter
    def foo(self, new_song):
        # overloading foo
        self._song = new_song


obj = Music5()
print('Song - ', obj.foo)
obj.foo = 'Hym For The Weekend'
print('New Song - ', obj.foo)