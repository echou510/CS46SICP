class Music3:
    # constructor
    def __init__(self):
        # These are private variables
        self.__genre = "Pop"
        self.__singer = "Coldplay"

    # private function
    def __func(self):
        print('Music: Hym For The Weekend')

    def foo(self):
        # Accessing private members of the class
        print("Genre:", obj.__genre)
        print("Singer:", obj.__singer)

# Creating object of the class
obj = Music3()

# Trying to access the private attributes from outside the class
obj.__func()
print("Genre:", obj.__genre)
print("Singer:", obj.__singer)