class Music2:
    # constructor
    def __init__(self):
        # These are private variables
        self.__genre = "Pop"
        self.__singer = "Coldplay"

    # private function
    def __func(self):
        print('Music: Hym For The Weekend')

    def foo(self):
        # Accessing private members of the class
        obj.__func()
        print("Genre:", obj.__genre)
        print("Singer:", obj.__singer)


obj = Music2()  # Creating an object of the Music class
obj.foo()  # calling the private function