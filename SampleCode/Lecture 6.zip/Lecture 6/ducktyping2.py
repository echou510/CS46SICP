import math
class ZeroCalc:
    def calculate(self, n):
        return 0
class SquareCalc:
    def calculate(self, n):
        return n * n
class CubeCalc:
    def calculate(self, n):
        return n * n * n
class LengthCalc:
    def calculate(self, n):
        return len(n)
class SquareRootCalc:
    def calculate(self, n):
        return math.sqrt(n)
class MultiplyByCalc:
    def __init__(self, multiplier):
        self._multiplier = multiplier
    def calculate(self, n):
        return n * self._multiplier

def run_calcs(calcs: ['Calc'], starting_value):
    current_value = starting_value
    for calc in calcs:
        current_value = calc.calculate(current_value)
    return current_value

a1 = run_calcs([SquareCalc(), SquareCalc()], 4)
print(a1)
a2 = run_calcs([LengthCalc(), MultiplyByCalc(2)], 'Boo')
print(a2)
a3 = run_calcs([], 80)
print(a3)
a4 = run_calcs([MultiplyByCalc(3), LengthCalc(), SquareCalc()], 'Boo')
print(a4)

