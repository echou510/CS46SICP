class Music:
    # Creating a constructor
    def __init__(self):
        self.genre = "Pop"
        self.singer = "Coldplay"
        # These are public attributes
    # Creating a function
    def foo(self):
        song = 'Hymn For The Weekend'
        return song
# Creating object of the class
m = Music()
# Accessing the members inside the class
print("Song: ", m.foo())
print("Genre:", m.genre)
print("Singer:", m.singer)