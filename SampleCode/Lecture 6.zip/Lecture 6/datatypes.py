print(dir(42))   # Integer (anprint(d the meaning of life)
print(dir([]))   # List (an empty list, actually)
print(dir(()))   # Tuple (also empty)
print(dir({}))   # print(dictionary (print(ditto)
print(dir(dir))  # Function (functions are also objects)

