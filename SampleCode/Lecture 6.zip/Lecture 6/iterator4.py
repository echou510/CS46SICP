from itertools import islice, cycle
colors = cycle(['red', 'white', 'blue'])  # infinite
limited = islice(colors, 0, 7)            # finite
for x in limited:                         # so safe to use for-loop on
    print(x)