import sys
def main(argc, argv):
    for i in range(1, argc):
        print(argv[i])

if __name__ == "__main__":
    argc = len(sys.argv)
    argv = sys.argv
    main(argc, argv)

    