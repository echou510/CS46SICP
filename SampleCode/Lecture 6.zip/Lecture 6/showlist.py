def list_attributes(obj):
    for attr_name in dir(obj):
        value = getattr(obj, attr_name)
        print(" %s:" % attr_name, value)
        if callable(value):
            pass
            #print("function/method")
        else:
            print(value)

list_attributes(list)
