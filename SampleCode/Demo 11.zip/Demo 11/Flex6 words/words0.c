#include <stdio.h>
#include "words.h"

extern int yylex(); 
extern int yylineno; 
extern char* yytext; 

char *names[] = {NULL};

int main(void){
  int ntoken, vtoken; 
  
  ntoken = yylex(); 
  while(ntoken){
	  printf("Toekn: %d\n", ntoken); 
	  printf("Text:    %s\n", yytext); 
	  printf("\n"); 
      ntoken = yylex(); 
  }
  return 0; 
}
