import re

pat = "([02-9]|1[01]?):[0-5][0-9](a|p)m"

alist = ["1:30pm", "23:18am", "32:00kk", "7:20pm", "10:32am"]
#mo = re.match(pat, "1:20am")
#print(mo)
for t in alist: 
    #print(t)
    mo = re.match(pat, t)
    if mo: print(mo.group(0))