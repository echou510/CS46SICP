import re
s = " ab ab aaaab aabbbb ab      abbba "
pat = "ab"
rePattern = re.compile("ab")

mo = rePattern.match(s)
if mo: print(mo.group(0)); print(mo.span())
print()

x = rePattern.sub("kk", s)
print(x)