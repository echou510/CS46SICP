import re

s = "abcde"
sno = "bcdedf"
pat = "a+"

mo = re.match(pat, s)
print(mo)

if mo: print(mo.group(0))
if mo: t = mo.span(); print(t); print(s[t[0]:t[1]])

no = re.match(pat, sno)
print(no)