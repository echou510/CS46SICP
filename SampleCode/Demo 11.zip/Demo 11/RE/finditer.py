import re

s = " ab ab aaaab aabbbb ab      abbba "
pat = "ab"

for itr in re.finditer(pat, s):
    t = itr.span()
    print(itr.group(0))
    print(t)
    #print(itr.start())
    #print(itr.end())

x = re.sub(pat, "kk", s)
print(x)
