import time

def fibo(n): 
    if n // 2 == 0: return 1 
    return fibo(n-1)+fibo(n-2)

N = 40
times = []
for i in range(N+1):   # i=0, N 
    start = time.time()
    print("fibo(%d) = %d" % (i, fibo(i)))
    end = time.time()
    times.append(end-start)

print() 
for i in range(N+1):
    print("fibo(%d) takes %.4f sec " % (i, times[i]))