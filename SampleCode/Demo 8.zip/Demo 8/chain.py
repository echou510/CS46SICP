def increase(x, step): 
    return x + step 

def make_func(func): 
    def g(step): 
        def h(x): 
            return func(x, step) 
        return h 
    return g

make_increase = make_func(increase)
increaseby2 = make_increase(2)
print(increaseby2(1))
print()

x = 0 
chain_functions = [make_increase(1), make_increase(2), make_increase(3)]

for f in chain_functions: 
    print(x)
    x = f(x)
print(x)
print()

inc1 = make_increase(1)
inc2 = make_increase(2)
inc3 = make_increase(3)
x = 0 
x = inc3(inc2(inc1(x))) 
print(x)





