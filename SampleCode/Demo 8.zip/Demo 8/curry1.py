def f(a, b): 
    return a + b 

a = 3
b = 4 
print("Traditional: ", f(a, b))
print() 

def add(base): 
    def g(x):
        return base + x
    return g  

add3 = add(3)
print("Function Factory: ", add3(4))
print()

x = add(3)(4)
print("Currying: ", x)
print()