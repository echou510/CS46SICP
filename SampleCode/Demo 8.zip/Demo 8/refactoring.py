def accumulator(x, a, b): 
    return a * x + b 

def multiply(x, a): 
    return a * x

def add(x, b): 
    return x + b 

A = 1 
B = 2 
i = 0 
x = 1
while i<5:  # from 1 to 5 
    print(x)
    x = accumulator(x, A, B)
    sum = x
    i += 1 

print("sum = ", sum)
print()

A = 1 
B = 2 
i = 0 
x = 1
while i<5:  # from 1 to 5 
    print(x)
    x = add(multiply(x, A), B) 
    sum = x
    i += 1 

print("sum = ", sum)
print()