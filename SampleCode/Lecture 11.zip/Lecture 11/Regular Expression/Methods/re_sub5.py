import re
# An example string.
v = "aabcaaadaf"
v = re.sub('(?P<A>a+)','(\g<A>)', v)
print(v)