import re
list = ["123", "4cat", "dog5", "6mouse"]
for element in list:
      # See if string starts in digit.
      m = re.match("^\d", element)
      if m: print("START:", element)
      # See if string ends in digit.
      m = re.match(".*\d$", element)
      if m: print(" END:", element)
