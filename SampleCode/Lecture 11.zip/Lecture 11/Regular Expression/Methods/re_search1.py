import re
# Input.
#        01234567890123
value = "voorheesville"
m = re.search("(vi.*)", value)
if m: # This is reached.
     print("search:", m.group(1))
     print(m.start())
     print(m.span())

m = re.match("(vi.*)", value)
if m: # This is not reached.
     print("match:", m.group(1))
