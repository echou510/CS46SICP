import re
plants = {"flower": 1, "tree": 1, "grass": 1}
def modify(m):
      v = m.group(0)
      # If string is in dictionary, return different string.
      if v in plants:
            return "PLANT"
      # Do not change anything.
      return v
# Modify to remove all strings within the dictionary.
result = re.sub("\w+", modify, "bird flower dog fish tree")
print(result)
