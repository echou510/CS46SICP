import re
# The input string.
input = "laugh231 eat32131 sleep think"
# Use lambda to add "ing" to all words.
result = re.sub("\w+", lambda m: m.group(0) + "ing", input)
# Display result.
print(result)
