import re
def add(m):
      # Convert.
      v = int(m.group(0))
      # Add 2.
      return str(v + 1)
# Call re.subn.
result = re.subn("\d+", add, "1 2 3 4 5")
print("Result string:", result[0])
print("Number of substitutions:", result[1])
