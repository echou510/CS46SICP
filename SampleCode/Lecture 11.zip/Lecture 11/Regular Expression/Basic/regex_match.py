import re

# matches Python Strings
matchObj= re.match("Python", "Python")
if matchObj == None: matching = False
else: matching = True
print("re.match(\"Python\", \"Python\")=", matching)

# matches zero or more characters
matchObj= re.match("Python.*", "Python is fun")
if matchObj == None: matching = False
else: matching = True
print("re.match(\"Python.*\", \"Python is fun\")=", matching)

# not matching \.
matchObj= re.match("Python\.+", "Python is cool")
if matchObj == None: matching = False
else: matching = True
print("re.match(\"Python\\.*\", \"Python is cool\")=", matching)

# not matching one or more space
matchObj= re.match("\s+", "")
if matchObj == None: matching = False
else: matching = True
print("re.match(\"\\s+\", \"\")=", matching)
# matching one or more space
matchObj= re.match("\s+", "   ")
if matchObj == None: matching = False
else: matching = True
print("re.match(\"\\s+\", \"   \")=", matching)

