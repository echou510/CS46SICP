import re

t="Demoadmin, demo_ms1, demo_ms2, my_clustr1"
p=re.compile('(d\w+)',re.I)
pos=0
while 1:
    m=p.search(t, pos)
    if m:
        print("Now search start position :", pos)
        print(m.group())
        start = m.start()
        #print(start)
        #print(m.span())
        pos = m.end()
    else:
        break
