import re
name = "Roberta Alden"
# Match names.
m = re.match("(?P<first>\w+)\W+(?P<last>\w+)", name)
if m: # Get dict.
     d = m.groupdict()
     # Loop over dictionary with for-loop.
     for t in d:
          print(" key:", t)
          print("value:", d[t])
