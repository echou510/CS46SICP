# phonep3.py
# problme 3:
# regular expression for July Fourth
import re
# Sample strings.
list = ["1-(000)111-7777", "0000","5-9999", "333-4444", "9999999", "7-2222", "1-(510)888-8888"]
# Loop.
for element in list:
     # Match if two words starting with letter d.
                  #12345678901234567890123456789012
     m = re.match("((1-\(\d{3}\))?\d\d)?\d-\d{4}", element)
     # See if success.
     if m:
           print(m.group(0))