# floatingpoint.py
# problme 6:
# regular expression floating point number
import re
# Sample strings.
list = ["0", "0.00", "100.0", "0.33","-102.5", "3.55", "0.0", "33",
        "-32.7423897423", "+2.55", "43.0e33", "3.22E+7843"]
# Loop.
for element in list:
     # Match if two words starting with letter d.
                  #12345678901234567890123456789012345678901234
     #m = re.match("^(\+|-)?(0|([1-9]\d*))\.\d+((E|e)(\+|-)?\d+)?$", element)
     m = re.match("^(0|-?[1-9]\d*)\.\d+((E|e)-?\d+)?$", element)
     # See if success.
     if m:
           print(m.group(0))