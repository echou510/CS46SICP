# grep.py
import re

def grep(filename, pattern):
    list=[]
    i = 1
    for line in open(filename, 'r').readlines():
        line = line.rstrip()
        m = pattern.match(line)
        if m: list.append((filename, i, line))
        i += 1
    return list

def main():
    filename = "data.txt"
    pattern = re.compile("(0|-?[1-9]\d*)")
    list = grep(filename, pattern)
    for f, lineno, st in list:
        print("%-10s Line %d %s" % (f, lineno, st))

if __name__ == "__main__":
    main()