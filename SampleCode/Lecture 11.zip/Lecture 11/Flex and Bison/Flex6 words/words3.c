#include <stdio.h>
#include <sys/file.h>
#include <string.h>
#include "words.h"

#define DEBUG 1

extern FILE *yyin; 
extern int yylex(); 
extern int yylineno; 
extern char* yytext; 

// Data Definition for tokens
char *names[] = {NULL};
 int ntoken, vtoken; 
 FILE *fp, *fq;                                       // file handler for token output file. 
 
int main(int argc, char *argv[]){

  // check parameter list
  if (argc!=3)  { printf("Usage: words3 input_file_name token_output_filename\n");  return 1; }
  char *fin = argv[1]; 
  char *fout = argv[2]; 
  fq = fopen(fin, "r"); 
  fp = fopen(fout, "w"); 
  
  if (fp && fq) yyin=fq; else return 1; 
  
  printf("Token File: %s\n", fout); 
  //
  //yyin = fq; 
  ntoken = yylex(); 
  while(ntoken){
	  if (ntoken <4 && ntoken >0){
		strlwr(yytext); 
	    if (DEBUG) printf("Toekn: %d\n", ntoken); 
	    if (DEBUG) printf("Text:    %s\n", yytext);
        fprintf(fp, "%s\n", yytext); 		
	    if (DEBUG) printf("\n"); 
	  }
      ntoken = yylex(); 
  }
  fclose(fq); 
  fclose(fp); 
  return 0; 
}
