#define WORD1      1
#define WORD2     2
#define WORD3     3
#define WORD4     4
#define SPACE       44
#define EOFX         99