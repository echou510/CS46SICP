#include <stdio.h>
#include <sys/file.h>
#include <string.h>
#include "words.h"

#define DEBUG 1

extern int yylex(); 
extern int yylineno; 
extern char* yytext; 

// Data Definition for tokens
char *names[] = {NULL};
 int ntoken, vtoken; 
 FILE *fp;                                       // file handler for token output file. 
 
int main(int argc, char *argv[]){

  // check parameter list
  if (argc!=2)  { printf("Usage: words2 token_output_filename < input_file_name \n");  return 1; }
  char *filename = argv[1]; 
  
  fp = fopen(filename, "w"); 
  
  printf("Token File: %s\n", filename); 
  //
  ntoken = yylex(); 
  while(ntoken){
	  if (ntoken <4 && ntoken >0){
		strlwr(yytext); 
	    if (DEBUG) printf("Toekn: %d\n", ntoken); 
	    if (DEBUG) printf("Text:    %s\n", yytext);
        fprintf(fp, "%s\n", yytext); 		
	    if (DEBUG) printf("\n"); 
	  }
      ntoken = yylex(); 
  }
  fclose(fp); 
  return 0; 
}
