def f(*args): 
    print(type(args))
    print(list(args))

f(1, 2, 4, 5, 6)

def g(**kwargs): 
    print(type(kwargs))
    print(kwargs)

g(a=1, b=2, c=3)