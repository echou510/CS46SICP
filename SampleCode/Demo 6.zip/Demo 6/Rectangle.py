class Rectangle: 
    def __init__(self, w=0, h=0):
        self.__width = w
        self.__height = h

    def getWidth(self): return self.__width
    def getHeight(self): return self.__height
    def setWidth(self, w=0): self.__width = w
    def setHeight(self, h=0): self.__height = h

    def __eq__(self, other): 
        if not (other is Rectangle): return False 
        return self.__width == other.__width and \
               self.__height == other.__height

    def __str__(self): 
        return "Rectangle[%d, %d]" % (self.__width, self.__height)

class Square(Rectangle): 
    def __init__(self, s=0): 
        super().__init__(s, s)

    def getSide(self): return self.getWidth() 
    def setSide(self, s=0): self.setWidth(s); self.setHeight(s)

    def __str__(self): 
        return "Square[%d]" % self.getWidth()

def main(): 
    r1 = Rectangle(3, 4)
    print(r1)
    s1 = Square(5)
    print(s1)

if __name__ == "__main__": 
    main()