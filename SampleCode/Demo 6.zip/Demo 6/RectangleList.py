from Rectangle import *

class RectangleList(list): 
    def __str__(self): 
        s = "["
        first = True
        for x in self: 
            if first: s+= str(x); first = False
            else: s += ", "+str(x)
        s += "]"
        return "RectangleList("+s+")"

def main(): 
    rlist1 = RectangleList()
    print(rlist1)
    r1 = Rectangle(30, 40)
    s1 = Square(50)

    rlist1.append(r1)
    rlist1.insert(1, s1)
    print(rlist1)

if __name__ == "__main__":
    main()