def max(x, y, *args): 
    if len(args)==0: return x if x > y else y
    m = x if x > y else y
    for z in args: 
        m = z if z > m else m
    return m 

print(max(5, 4)); 
print(max(3.0, 7.0)); 
print(max(2, 5, 4)); 
