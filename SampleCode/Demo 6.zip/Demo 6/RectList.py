from Rectangle import *
class RectList: 
    def __init__(self, rlist=[]): 
        self.__data = rlist

    def size(self):
        return len(self.__data)
    
    def empty(self):
        return len(self.__data)==0

    def get(self, idx): return self.__data[idx]
    def set(self, idx, val): 
        if idx <0 or idx >= len(self.__data): return None
        r = self.__data[idx]
        self.__data[idx] = val
        return r 
    def append(self, val): self.__data.append(val)
    def insert(self, idx=0, val=0): self.__data.insert(idx, val)
    def remove(self, idx): 
        if idx <0 or idx >= len(self.__data): return None
        r = self.__data[idx]
        self.__data.pop(idx)
        return r 
    
    def __eq__(self, other): 
        if not (other is RectList): return False
        return self.__data == other.__data

    def __str__(self): 
        s = "["
        first = True
        for x in self.__data: 
            if first: s+= str(x); first = False
            else: s += ", "+str(x)
        s += "]"
        return "RectList("+s+")"


def main(): 
    rlist1 = RectList()
    print(rlist1)
    r1 = Rectangle(30, 40)
    s1 = Square(50)

    rlist1.append(r1)
    rlist1.insert(1, s1)
    print(rlist1)

if __name__ == "__main__":
    main()
