from Rectangle import Rectangle, Square

r1 = Rectangle(30, 40)
print(r1)
s1 = Square(50)
print(s1)