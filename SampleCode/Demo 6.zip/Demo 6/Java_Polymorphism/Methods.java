
/**
 * Write a description of class Methods here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Methods
{
    public static int max(int x, int y){
       return (x>y) ? x : y; 
    }
    
    public static double max(double x, double y){
       return (x>y) ? x : y; 
    }
    
    public static int max(int x, int y, int z){
       int m = (x>y) ? x : y; 
       return (m>z) ? m : z; 
    }
    
    public static void main(String[] args){
      System.out.println(max(5, 4)); 
      System.out.println(max(3.0, 7.0)); 
      System.out.println(max(2, 5, 4)); 
    }
}
