from pylab import *
import numpy as np 
import pprint
ary1 = np.array([1, 2, 3])
list1 = list(ary1)
print(ary1)
print(list1)

m1 = np.array([[1, 2],[3, 4]])

print("m1:", m1)
print(m1.ndim)
print(m1.size)
print(m1.shape)
#matrix1.reshape(1, matrix1.size())
#print(marray)
a = np.array([1, 2, 3, 4]) 
a = a.reshape((2, 2))
print(a)
m1 = m1.reshape((1, 4))[0]
print("After Reshape: ", m1)

import numpy.random as rd 

x = rd.randint(10, size=100)
print(x)

f = np.full(10, fill_value=1000)
print(f)
#f2 = np.full(10, full_value=rd.randint(44))
r = np.array([1, 2, 3, 4])
c = r.reshape((4, 1))
print(r)
print(c.shape)

pprint.pprint(c)

a = np.array([1, 2])
b = np.array([3, 4])
print(a.dot(b))
print(a@b)  # @ same as inner product . 