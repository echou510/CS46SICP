student1 = {
  "name": "Eric Chou", 
  "age": 15, 
  "score": 99
}

print(student1)
student1["math"] = 88  # add an data field 
print("Student 1: ", student1)

student2 = dict()
print(student2)
student2["name"] = "Ariel"
student2["age"] = 16
student2["score"] = 76
student2["math"] = 44
print("Student 2:", student2)

from collections import defaultdict
student3 = defaultdict()
student3["name"] = "Bryant"
student3["age"] = 17
student3["score"] = 100
#print(student3["math"])

for k in student1:  #getting key
    print(k)

for t in student1.items():  # get (key, val)
    print(t)

for k in student1.keys():  # get keys
    print(k)

for v in student1.values(): 
    print(v)