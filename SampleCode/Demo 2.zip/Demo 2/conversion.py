from pylab import * 
import numpy as np 

x = list(np.linspace(0, 10, 101))
y = [np.sqrt(t) for t in x]

figure()
plot(x, y, 'b')
show()



