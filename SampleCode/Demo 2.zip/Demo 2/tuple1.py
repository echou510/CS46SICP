t1 = (1, 2)
print(t1)
print(len(t1))
t2 = (3)
print(t2)
t3 = ()
print(t3)
#t2[0] = 4
#print(t2)
#print(t2[0])
t2 = (3,)
print(t2)
print(t2[0])
print(t1[1])
# t1[1] = 10   You can't assign a new value to a tuple
t1 = (t1[0], 10) # redirect t1 reference to a new tuple. 

print(t1)
#t1.append(20)

for x in t1: 
    print(x)

t1 = ('a', 'b', 'c')
print("".join(t1))  # joining tuple of char is ok. 