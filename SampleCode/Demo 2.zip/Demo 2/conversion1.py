from pylab import * 
import numpy as np 
import random as rd
x = [rd.randint(0, 100) for i in range(101)]
y = [rd.randint(0, 100) for t in x]
points = list(zip(x, y))
print("Before Sorting: ", points)

points = sorted(points, key=lambda t: t[1])
points = sorted(points, key=lambda t: t[0])

print("After Sorting: ", points)
x_new = [t[0] for t in points]
y_new = [t[1] for t in points]
"""
figure()
scatter(x_new, y_new, color='b')
show()
"""

points2 = dict()
for t in points: 
    points2[t[0]] = t[1]

print(points2)