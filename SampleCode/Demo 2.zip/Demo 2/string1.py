s1 = 'c'  # character, Python String and char 
s2 = "abc"
s3 = """abcdef"""
sf = "\n"
print(sf)
print(type(sf)) 
   #-10987654321
    #012345678901
s = "abcdefghijk"
print(s[2])

# s[start:end:step]
print(s[1:11:2])
print(s[2])
# s[start:end:1]
print(s[0:4])
# s[:end:step] = s[0:end:step]
print(s[:11:2])
# s[start::step] = s[start:len(s):step]
print(s[3::3])
# s[-1] = s[len(s)-1]
print(s[-1])
# s[-4] = s[len(s)-4]
print(s[-4])
# s[-7:-3] = s[len(s)-7:len(s)-3:1]
print(s[-7:-3])
# s[len(s)-1:0:-1]
print(s[::-1])  # reverse of the string
# s[-4::-1]     # s[len(s)-4:start:-1]
print(s[-4::-1])

print("*"*10)

for ch in s[::-1]: 
    print(ch, end=" ")
print()
b = "brown".capitalize()
print(b)
c3 = s.center(3)
print(c3)
x = "ababaababababab"
print(x.count("ab"))

slist = list(s)
print(slist)
sx = "*".join(slist)
print(sx)

print(s.find("g"))
print(s.find("z"))

t = "ab ab aaaab ababa ab aaabbb"
print("Location of ab:", end="")
pos = t.find("ab")
while pos >=0: 
    print(pos, end=" ")
    pos = t.find("ab", pos+1)
print()

st = "\t\tab\ncd\t\t\t"
print(st)
sw = st.lstrip()
print(sw)
sy = st.rstrip()
print(sy)
sb = st.strip()
print(sb)

tokens = "a b c d e f g"
tlist = tokens.split()
print(tlist)

sf = "(%d, %d)" % (3, 4)  # stardard c-like formatted string
print(sf)
sf2 = "({0}, {1})".format(3, 4)  #python formatted string
print(sf2)
sf4 = "{1}, {0}, {1}, {0}".format(3, 4)
print(sf4)

name = "Eric Chou"
age = "15"
score = "99"
print(f"Name: {name}, Age:{age}, Score:{score}")