s = {}
slist = list(s)
slist.append(1)
s = set(slist)
print(s)

def add(s, val): 
    s |= {val}  # union
    return s
    
def remove(s, val):
    s -= {val}  # set difference
    return s

add(s, 2)
print(s)
remove(s, 1)
print(s)
