import numpy as np
t1 = (1, 2, 3)
tlist1 = list(t1)
print(tlist1)
t2 = tuple(tlist1)
print(t2)

a = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21]
print(a[::-1])
a.append(23)
print(a)

a = [1,2, 3]
a.append(4)
print(a)
a.pop()
print(a)
a.insert(0, 0)
print(a)
a.remove(0)
print(a)
a.insert(1, 1.5)
print(a)
a.pop(1)
print(a)
alphabet = [chr(kor) for kor in range(65, 91)]
print(alphabet)
astr = "".join(alphabet)
print(astr)
a = [1, 2, 3]
b = [4, 5, 6]
c = a + b
print(c)

alist = []
for x in range(10): 
    #print(x)
    #alist.append(x)
    alist += [x]
print(alist)

ary = [0] * 20  # int[] ary = new int[20]
print(ary)
for i in range(len(ary)): 
    ary[i] = i
print(ary)

s = [5, 2, 6, 4, 1]
s.sort()
print(s)
s.sort(reverse=True)
print(s)

t = [5, 2, 6, 4, 1]
t2 = sorted(t)
print(t2)
print(t)

points = [(3, 1), (2, 4), (10, 2), (1, 9)]
p1 = sorted(points, key=lambda t: t[0])
p2 = sorted(points, key=lambda t: t[1])
print("Sorted by x: ", p1)
print("Sorted by y: ", p2)

tary = np.array(t)  # arraylist to array in Java
print(tary)

m = [[1, 2], 
     [3, 4]]
    
m1 = np.array(m)
print(m1)