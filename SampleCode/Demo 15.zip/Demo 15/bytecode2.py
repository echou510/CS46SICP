import dis
code = '''
def add(a, b): 
    return a + b 
add(5, 7)
'''

co = dis.dis(code)
print(co)