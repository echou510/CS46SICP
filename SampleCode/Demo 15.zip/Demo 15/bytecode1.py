import dis
def add(a, b): 
    return a+b

print(add.__code__.co_code)
print(list(add.__code__.co_code))
print(dis.dis(add))
print(dis.opname)  # opcode for python virtual 
                   # 8-byte virtual opcode for python virtual machine