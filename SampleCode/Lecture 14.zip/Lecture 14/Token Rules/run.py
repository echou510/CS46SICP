import ply.lex as lex
import tokrules
lexer = lex.lex(module=tokrules)

print(lexer.input("3 + 4"))
print(lexer.token())         # LexToken(NUMBER,3,1,1,0)

print(lexer.token())         #LexToken(PLUS,'+',1,2)

print(lexer.token())         #LexToken(NUMBER,4,1,4)

print(lexer.token())         # None