import ply.lex as lex

tokens = (
   'NUMBER',
   'SYMBOL', 
   'ID'
)

def makeMonkey(): 
    # Regular expression rules for simple tokens
    t_ID    = r'[a-zA-Z]{1}[A-Za-z0-9]*'
    t_SYMBOL = r'[^a-zA-Z0-9]{1}'

    # A regular expression rule with some action code
    def t_NUMBER(t):
        r'\d+'
        t.value = int(t.value)    
        return t

    # Define a rule so we can track line numbers
    def t_newline(t):
        r'\n+'
        t.lexer.lineno += len(t.value)

    # A string containing ignored characters (spaces and tabs)
    t_ignore  = ' \t'

    # Error handling rule
    def t_error(t):
        print("Illegal character '%s'" % t.value[0])
        t.lexer.skip(1)
    return lex.lex() 

monkeylex = makeMonkey()
# REPL console
line = input(">>> ")
while line.lower()!="exit": 
    data = line.strip()
    # Tokenize
    monkeylex.input(data)
    for tok in monkeylex: 
        print(tok)
    print()
    line = input(">>> ")
