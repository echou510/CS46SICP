import ply.lex as lex

class monkeylex():
    tokens = (
        'NUMBER',
        'SYMBOL', 
        'ID'
    )

    # Regular expression rules for simple tokens
    t_ID    = r'[a-zA-Z]{1}[A-Za-z0-9]*'
    t_SYMBOL = r'[^a-zA-Z0-9]{1}'

    # A regular expression rule with some action code
    def t_NUMBER(self, t):
        r'\d+'
        t.value = int(t.value)    
        return t

    # Define a rule so we can track line numbers
    def t_newline(self, t):
        r'\n+'
        t.lexer.lineno += len(t.value)

    # A string containing ignored characters (spaces and tabs)
    t_ignore  = ' \t'

    # Error handling rule
    def t_error(self, t):
        print("Illegal character '%s'" % t.value[0])
        t.lexer.skip(1)

    def build(self, **kwargs): 
        self.lexer = lex.lex(module=self, **kwargs)

    def run(self):
        line = input(">>> ")
        while line.lower()!="exit": 
            data = line.strip()
            # Tokenize
            self.lexer.input(data)
            for tok in self.lexer: 
                print(tok)
            print()
            line = input(">>> ")

# Build the lexer and try it out
def main(): 
    m = monkeylex()
    m.build()
    m.run()

if __name__ == "__main__": 
    main()