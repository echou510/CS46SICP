import ply.lex as lex
import monkeyrules

# Build the lexer for Monkey Language
lexer = lex.lex(module=monkeyrules)
# REPL console
line = input(">>> ")
while line.lower()!="exit": 
    data = line.strip()
    # Tokenize
    lexer.input(data)
    for tok in lexer: 
        print(tok)
    print()
    line = input(">>> ")