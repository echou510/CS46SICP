from itertools import islice
def get(): # Generating function
    i = 0
    while True: 
        yield i
        i += 1

g = get() # g is a generator and is also an iterator
print(next(g)) 
print(next(g))
"""
g = get()
alist = list(islice(g, 0, 6))
print(alist)
"""