class vec: 
    def __init__(self, a):  # a is list
        self.data = a
        self.idx = 0  

    def __iter__(self): 
        self.idx = 0
        return self
    
    def __next__(self): 
        if self.idx>=len(self.data): raise StopIteration
        r = self.data[self.idx]
        self.idx += 1
        return r 
    def __str__(self): 
        s = str(self.data)
        return s

v = vec([1, 2, 3])
print(v)

itr = iter(v)
n = next(itr)
print(n)
n = next(itr)
print(n)
n = next(itr)
print(n)
print()
print()
itr = iter(v)
done = False
while not done: 
    try: 
        d = next(itr)
        print(d)
    except: 
        done = True

print("Done")
    
for x in v: 
    print(x)