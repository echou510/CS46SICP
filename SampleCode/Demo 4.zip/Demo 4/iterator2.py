a = [2, 4, 6, 8, 10]
itr = iter(a)  # create a pointer
#z = []
#itr2 = iter(z)

done = False
while not done: 
    try: 
        d = next(itr)
        print(d)
    except: 
        done = True

print("Done")

