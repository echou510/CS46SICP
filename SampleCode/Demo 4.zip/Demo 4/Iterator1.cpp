#include <iostream> 
#include <vector> 

using namespace std; 

vector<int> a{2, 4, 6, 8, 10}; 

int main(){
    for (int i=0; i<a.size(); i++){
     cout << a[i] << endl; 
    }
    cout << endl << endl; 

    for (vector<int>::iterator itr=a.begin(); itr != a.end(); itr++){
        cout << *itr << endl; 
    }

    cout << endl << endl; 
    for (int x: a){
        cout << x << endl; 
    }
    return 0; 
}