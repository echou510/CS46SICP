import java.util.ArrayList; 
public class DoWhile
{
    static String a = "abcdedgabaaaaa ab aba abbb ababa bab"; 
    
    public static void main(String[] args){
       System.out.print("\f");  // clean up the page
       ArrayList<Integer> ab_locations = new ArrayList<Integer>(); 
       int pos = -1; 
       do {
           pos = a.indexOf("ab", pos+1);  
           if (pos>=0) ab_locations.add(pos); 
        } while (pos>=0);  // Continue condition is pos>=0, exit condition will be !(pos>=0) == pos <0  when not found
       
       System.out.println(ab_locations); 
    }
}
