a = [2, 4, 6, 8, 10]
for i in range(len(a)):  # (0, 1, 2, 3, 4)
    print(a[i])

print()
for x in a: # for-each for each element x in a
    print(x)
