age = 0 
done = False
while not done:  # !(not done) == Exit condition 
    try: 
        age = int(input("Enter Your Age: "))
        if age <0: raise BaseException("Range Error: Negative")
        if age >150: raise BaseException("Range Error: Too Large")
        done = True
    except BaseException as e: 
        print(e)
    except: # general case
        print("Wrong Input Format")

# post-condition: !(not done) ==> done
print(age)