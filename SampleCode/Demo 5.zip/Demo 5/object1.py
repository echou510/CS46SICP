d = {
    "name": "Eric",
    "age": 18
}

print(d)