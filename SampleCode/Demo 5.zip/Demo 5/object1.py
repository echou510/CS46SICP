import math
def f(p):
    return math.sqrt(p['x']**2+p['y']**2) 

obj = {
    'x': 3, 
    'y': 4, 
    'distance': f
}

print(obj['x'])
print(obj['y'])
print(obj['distance'](obj))

obj['z'] = 3 
print(obj['z'])

print(type(obj))

print(obj)