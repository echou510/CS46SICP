import math

def tag(func): 
    def w(self):  # wrapper function takes all the parameters
        return "<"+func(self)+">" # passing self to the function. 
    return w

class point: 
    def __init__(self, x, y): 
        self.x = x
        self.y = y

    @staticmethod
    def distance(p1, p2):
        x1 = p1.x
        x2 = p2.x
        y1 = p1.y
        y2 = p2.y
        return math.sqrt((x1-x2)**2 + (y1-y2)**2) 

    @property   # derived data field
    def distanceToOrigin(self): 
        p0 = point(0, 0)
        return point.distance(self, p0)

    #distance = staticmethod(distance)
    @tag
    def display(self): 
        return str(self.x)+", "+str(self.y)

px = point(0, 0)
py = point(3, 4)
print(point.distance(px, py))
print(py.distanceToOrigin)

print(px.display())


