import math

def paren(f): 
    def nf(self, opentag, closetag): 
        return opentag+f(self)+closetag
    return nf

class point: 
    def __init__(self, x=0, y=0): 
        self.x = x
        self.y = y 

    @paren
    def coordinate(self): 
        return str(self.x) + ", " + str(self.y)

    def display(self): 
        return self.coordinate("(", ")")
    
    @staticmethod
    def length(p):  # static method: utility method
        return math.sqrt(p.x*p.x+p.y*p.y) 

    @classmethod
    def leng(cls, p): 
        return 2*math.sqrt(p.x*p.x+p.y*p.y) 

    @property   # derived data field
    def square_distance_from_origin(self): 
        return self.x + self.y


    def __eq__(self, other): 
        return self.x == other.x and self.y == other.y

    def __str__(self): 
        return "(%d, %d)" % (self.x, self.y)

class location(point): 
    def __init__(self, lx=0, ly=0): 
        super().__init__(lx, ly)

    @classmethod
    def leng(cls, p): 
        return 3*math.sqrt(p.x*p.x+p.y*p.y) 

p0 = point(2, 2)
p1 = location(2, 2)

print("Methods from decorate2.py: ")
len_p0 = point.length(p0)
print("static(p0): ", len_p0)
len_p1 = location.length(p1)
print("static(p1): ", len_p1)

leng_p0 = point.leng(p0)
print("class(p0): ", leng_p0)
leng_p1 = location.leng(p1)
print("class(p1): ", leng_p1)

print()
print("Methods from decorate3.py: ")
print("p1==p0 is ", (p1==p0))
print("p0==p1 is ", (p0==p1))
print("p0.__dict__", p0.__dict__)
print("p1.__dict__", p1.__dict__)

print()
print("Methods from decorate4.py: ")
coP0 = p0.coordinate("(", ")")
print(coP0)
displayP0 = p0.display()
print(displayP0)

print()
print("Methods from decorate5.py: ")
print(p0.square_distance_from_origin)
