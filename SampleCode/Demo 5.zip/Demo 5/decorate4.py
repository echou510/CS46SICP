import math

def tag(f): 
    def nf(tagname, opentag, closetag): 
        return opentag+f(tagname)+closetag
    return nf

def func(tagname): 
    return tagname

def paren(f): 
    def nf(self, opentag, closetag): 
        return opentag+f(self)+closetag
    return nf

class point: 
    def __init__(self, x=0, y=0): 
        self.x = x
        self.y = y 

    def coordinate(self): 
        return str(self.x) + ", " + str(self.y)

    coordinate = paren(coordinate)

    def display(self): 
        return self.coordinate("(", ")")
    
    def length(p):  # static method: utility method
        return math.sqrt(p.x*p.x+p.y*p.y) 
    length = staticmethod(length)  # staticmethod is a function factory

    def leng(cls, p): 
        return 2*math.sqrt(p.x*p.x+p.y*p.y) 

    leng = classmethod(leng)

    def __eq__(self, other): 
        return self.x == other.x and self.y == other.y

    def __str__(self): 
        return "(%d, %d)" % (self.x, self.y)

class location(point): 
    def __init__(self, lx=0, ly=0): 
        super().__init__(lx, ly)

    def leng(cls, p): 
        return 3*math.sqrt(p.x*p.x+p.y*p.y) 
    
    leng = classmethod(leng)

p0 = point(2, 2)
p1 = location(2, 2)

maketag = tag(func)

paragraph_tag = maketag("p", "<", ">")
print(paragraph_tag)

div_tag = maketag("div", "<", ">")
print(div_tag)

coP0 = p0.coordinate("(", ")")
print(coP0)

displayP0 = p0.display()
print(displayP0)
