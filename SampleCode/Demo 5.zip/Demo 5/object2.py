class point:
    """Point Class: 
          Point(x, y): constructor
          repr(p): representation function
          str(p): conversion of the object into a string
    """
    def __init__(self, x=0, y=0):  # dunder __ magic function 
        self.x = x   # self -- this in Java current object reference
        self.y = y   # self.x is an instance variable 
    def __eq__(self, other): 
        if (type(other)!=point): return False
        return self.x == other.x and self.y == other.y
    def __repr__(self): 
        return "(%.2f, %.2f)" % (self.x, self.y)
    def __str__(self):  # toString in Java
        return "<%.2f, %.2f>" % (self.x, self.y)

p = point()
print(p)
print(str(p))

s = "Ok: " + repr(p) 
print(s)

q = point(0, 0)

print("p==q is ", p==q)
print("p==s is ", p==s)
print(point.__dict__)
print(point.__doc__)
print(point.__name__)
print(point.__module__)
print(point.__bases__)

del q
# print(q)   # undefined