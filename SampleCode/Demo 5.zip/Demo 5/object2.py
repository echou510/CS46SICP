import math 

class point:
    """Point Class: 
          Point(x, y): constructor
          repr(p): representation function
          str(p): conversion of the object into a string
    """
    numbers = 0
    def __init__(self, x=0, y=0): 
        self.x = x
        self.y = y 
        point.numbers += 1
        self.__nickname = "location"

    def getX(self): return self.x
    def getY(self): return self.y
    def setX(self, x): self.x = x
    def setY(self, y): self.y = y
    def display(self):
        print(self.__nickname)

    def __eq__(self, other):
        if type(other)!= point: return False 
        return self.x==other.x and self.y==other.y
    def __repr__(self): 
        return "<%d, %d>" % (self.x, self.y) 
    def __str__(self): 
        return "(%d, %d)" % (self.x, self.y) 

p = point()
print(p)
p1 = point(3, 4)
print(p1)
print("p1.x == ", p1.getX())
print("p1.y == ", p1.getY())
print(type(p))
print(dir(p))
print(point.__doc__)
print(point.__dict__)
print(point.__name__)
print(point.__module__)
print(point.__bases__)


q = point(10, 10)
print(q)

del q 
#print(q)

r = point(3, 4)

print("p1==r is ", (p1==r))
print("p1==(3, 4) is ", (p1==(3, 4)))
print("Number of points created: ", point.numbers)

p.display()
#print(p.__nickname)  not ok

print(getattr(p, "x"))
setattr(p, "y", 100)
print("After setattr: ", p)
