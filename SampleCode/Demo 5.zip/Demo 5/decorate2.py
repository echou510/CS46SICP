import math

class point: 
    def __init__(self, x=0, y=0): 
        self.x = x
        self.y = y 
    
    def length(p):  # static method: utility method
        return math.sqrt(p.x*p.x+p.y*p.y) 
    length = staticmethod(length)  # staticmethod is a function factory

    def leng(cls, p): 
        return 2*math.sqrt(p.x*p.x+p.y*p.y) 

    leng = classmethod(leng)

    def __str__(self): 
        return "(%d, %d)" % (self.x, self.y)

class location(point): 
    def __init__(self, lx=0, ly=0): 
        super().__init__(lx, ly)

    def leng(cls, p): 
        return 3*math.sqrt(p.x*p.x+p.y*p.y) 
    
    leng = classmethod(leng)

p0 = point(2, 2)
p1 = location(2, 2)
len_p0 = point.length(p0)
print("static(p0): ", len_p0)
len_p1 = location.length(p1)
print("static(p1): ", len_p1)

leng_p0 = point.leng(p0)
print("class(p0): ", leng_p0)
leng_p1 = location.leng(p1)
print("class(p1): ", leng_p1)