import math

class point: 
    def __init__(self, x=0, y=0): 
        self.x = x
        self.y = y 
    
    def length(p):  # static method: utility method
        return math.sqrt(p.x*p.x+p.y*p.y) 
    
    length = staticmethod(length)  # staticmethod is a function factory

    def __str__(self): 
        return "(%d, %d)" % (self.x, self.y)

p = point()
p1 = point(3, 4)
print(p)
normP = point.length(p1) # staticmethod works, class inner function yes
print(normP)

print(dir(p))

normP2 = p.length(p1)  # staticmethod works, class inner function no
print(normP2)

