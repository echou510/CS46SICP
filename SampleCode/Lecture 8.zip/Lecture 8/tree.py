def tree(label, branches=[]): 
    return [label]+ list(branches)
def label(tree): 
    return tree[0]
def branches(tree): 
    return tree[1:]
def is_leaf(tree): 
    return len(branches(tree)) == 0
t = tree(3, [
            tree(1),
            tree(2, [
                tree(1), 
                tree(1)
            ])
        ])

lx = label(t); print(lx)  # 3
tx = is_leaf(branches(t)[0]); print(tx) # true