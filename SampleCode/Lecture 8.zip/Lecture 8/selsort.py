a = [5, 1, 45, 13, 23, 88, 2]

def rselsort(a):
    return rselsorthelper(a, 0)

def minIdx(a, i, mm, mi):   
    if i >= len(a): return mi
    if mm > a[i]: return minIdx(a, i+1, a[i], i)
    return minIdx(a, i+1, mm, mi)

print(minIdx(a, 3, a[3], 3))

def rselsorthelper(a, i):
    if i >= len(a): return a
    idx = minIdx(a, i, a[i], i)
    if i!=idx: 
        tmp = a[i]
        a[i] = a[idx]
        a[idx] = tmp
    return rselsorthelper(a, i+1)

a = rselsort(a)
print(a)