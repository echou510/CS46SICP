def tree(label, branches=[]): 
    return [label]+ list(branches)

def label(tree): 
    return tree[0]

def branches(tree): 
    return tree[1:]

def is_leaf(tree): 
    return len(branches(tree)) == 0

def count_leaves(t): 
    if is_leaf(t): 
        return 1
    else: 
        leaves_under = 0 
        for b in branches(t): 
            leaves_under += count_leaves(b)
        return leaves_under

def count_leaves_sum(t): 
    if is_leaf(t): 
        return 1
    else: 
        leaves_unders = [count_leaves_sum(b) for b in branches(t)] 
        return sum(leaves_unders)

def copy(t): 
    if is_leaf(t): 
        return tree(label(t))
    else: 
        return tree(label(t), [tree(b) for b in branches(t)])

def print_tree(t, indent=0):
    print(indent*" ", label(t))
    for b in branches(t):
        print_tree(b, indent+3)

t = tree(3, [
            tree(1),
            tree(2, [
                tree(1), 
                tree(1)
            ])
        ])

t2 = copy(t)
print(t2)

print_tree(t)

