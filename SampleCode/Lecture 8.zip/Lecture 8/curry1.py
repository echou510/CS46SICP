curry2 = lambda f: lambda x: lambda y: f(x, y)

from operator import add
make_adder = curry2(add)
x = make_adder(2)(3)
print(x)