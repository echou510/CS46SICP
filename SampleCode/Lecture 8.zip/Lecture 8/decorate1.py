"""Return a function that takes a single argument, x, prints it,
computes and prints F(x), and returns the computed value.
>>> square = lambda x: x * x
>>> trace1(square)(3)
-> 3
<- 9
9
"""
def trace1(f):
    def traced(x):
        print("->", x)
        r = f(x)
        print("<-", r)
        return r
    return traced

def square(x):
	return x * x
square = trace1(square)
print(square(3))
