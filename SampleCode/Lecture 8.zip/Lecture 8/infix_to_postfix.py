class Stack:
    def __init__(self):
        self.items = []
    def isEmpty(self):
        return self.items == []
    def push(self, item):
        self.items.append(item)
    def pop(self):
        if self.isEmpty():
            return None
        return self.items.pop()
    def peek(self):
        if self.isEmpty():
            return None
        return self.items[len(self.items)-1]
    def size(self):
        return len(self.items)
    def __str__(self):
        return str(self.items)

precedence = {}
precedence['*'] = 3
precedence['/'] = 3
precedence['+'] = 2
precedence['-'] = 2
precedence['('] = 1


def convert(expression):
    return __convert(expression.split())

def __convert(tokens):
    postfix = []
    opstack = Stack()

    for token in tokens:
        if token.isidentifier():
            postfix.append(token)
        elif token == '(':
            opstack.push(token)
        elif token == ')':
            while True:
                temp = opstack.pop()
                if temp is None or temp == '(':
                    break
                elif not temp.isidentifier():
                    postfix.append(temp)

        else:  # must be operator
            if not opstack.isEmpty():
                temp = opstack.peek()

                while not opstack.isEmpty() and precedence[temp] >= precedence[token] and token.isidentifier():
                    postfix.append(opstack.pop())
                    temp = opstack.peek()

            opstack.push(token)

    while not opstack.isEmpty():
        postfix.append(opstack.pop())

    return postfix

def toString(items):
    string = ""
    for i in range(len(items)):
        string = string + str(items[i])
    return string

list1 = convert("A + B")
print("Postfix: ", toString(list1))
list2 = convert("A + B * C")
print("Postfix: ", toString(list2))
list3 = convert("A * ( B + C ) + D")
print("Postfix: ", toString(list3))
list4 = convert("A + B * ( C - D ) * D")
print("Postfix: ", toString(list4))
