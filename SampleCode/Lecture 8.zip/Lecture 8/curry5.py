curry2 = lambda f: lambda x: lambda y: f(x, y)
def html_tag(tag_name, text):
	return "<" + tag_name + ">" + text + "</" + tag_name + ">"

p_tag = curry2(html_tag)("p")
x = p_tag("hello hello")
print(x)
