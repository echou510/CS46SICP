
from operator import add
curry2 = lambda f: lambda x: lambda y: f(x, y)

def transform_numbers(num1, num2, num3, transform):
    return (transform(num1), transform(num2), transform(num3))

x = transform_numbers(3, 4, 5, curry2(add)(60))
print(x)

