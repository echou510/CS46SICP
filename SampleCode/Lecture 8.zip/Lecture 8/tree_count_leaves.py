def tree(label, branches=[]): 
    return [label]+ list(branches)

def label(tree): 
    return tree[0]

def branches(tree): 
    return tree[1:]

def is_leaf(tree): 
    return len(branches(tree)) == 0

def count_leaves(t): 
    if is_leaf(t): 
        return 1
    else: 
        leaves_under = 0 
        for b in branches(t): 
            leaves_under += count_leaves(b)
        return leaves_under

def count_leaves_sum(t): 
    if is_leaf(t): 
        return 1
    else: 
        leaves_unders = [count_leaves_sum(b) for b in branches(t)] 
        return sum(leaves_unders)

t = tree(3, [
            tree(1),
            tree(2, [
                tree(1), 
                tree(1)
            ])
        ])

leaves = count_leaves(t)
print(leaves)
count_leaves_sum(t)