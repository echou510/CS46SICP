def f(*args): 
    for i in range(len(args)): 
        print(args[i])


f(1, 2, 3, 4, 5, 6)  # grouping 1, 2, 3, 4, 5 into a list

def g(**kwargs): 
    print(kwargs)

g(a=1, b=2, c=3)

def h(**kwargs): 
    for p in kwargs: 
        print(p, "=", kwargs[p])

h(a=1, b=2, c=3)