def prefixToPostfix(prefix):
    # Reversing the order
    s = prefix[::-1]
    stack = []

    for i in s:
        if i in "+-*/^":
            a = stack.pop()
            b = stack.pop()
            temp = a+b+i
            stack.append(temp)
        else:
            stack.append(i)

    p = "".join(stack)
    return p

print(prefixToPostfix("*-A/BC-/AKL"))
