def bin(a, key): 
    low = 0
    high = len(a)-1
    while low<=high:  # exit condition: cross over 
        mid = (low+high)// 2
        if (a[mid]==key): return mid 
        elif (a[mid]>key): high = mid -1
        else: low = mid +1
    return -1

def binT(a, key):
    return binHelper(a, key, 0, len(a)-1)
    #return binHelper()

def binHelper(a, key, low, high): 
    if (low > high): return -1
    mid = (low+high)//2
    if (a[mid]==key): return mid
    elif (a[mid]>key): return binHelper(a, key, low, mid-1)
    return binHelper(a, key, mid+1, high)

x = [1, 5, 6, 8, 7, 12, 15]

print(binT(x, 3))
print(binT(x, 15))
print(binT(x, 1))