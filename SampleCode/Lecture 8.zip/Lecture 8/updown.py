def num_eights(n): 
    if (n==0): return 0
    d = n % 10
    if (d==8): return 1+num_eights(n//10)
    return num_eights(n//10)

print(num_eights(8888))
print(num_eights(1810810182))

def pingpong(n): 
    def pk(num, ch):
        if (num==1): return (1, True)     # (1 and up)
        ch1 = (num-1)%8==0 or num_eights(num-1)
        (r, up) = pk(num-1, ch1)
        if (up): return (1+r, ch != up)
        return (-1+r, ch != up)

    c = n%8==0 or num_eights(n)
    return pk(n, c)[0]   # get the first element of the tuple. 

for i in range(1, 31): 
    print("pingpong(%d)=%d\n" % (i, pingpong(i)))
