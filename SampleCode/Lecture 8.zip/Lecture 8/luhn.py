def sum_digits(n):
    if n<10: 
        return n
    else: 
        last = n % 10 
        all_but_last = n // 10
        return last + sum_digits(all_but_last)

def luhn_sum(n): 
    if n<10: 
        return n
    else: 
        last = n % 10 
        all_but_last = n // 10
        return last + luhn_sum_double(all_but_last)

def luhn_sum_double(n): 
    last = n % 10 
    all_but_last = n // 10 
    luhn_digit = sum_digits(last * 2)
    if n < 10: 
        return luhn_digit
    else: 
        return luhn_digit + luhn_sum(all_but_last)

sum = luhn_sum(138743)
print(sum)