def curry2(f):
    def g(x):
        def h(y):
            return f(x, y)
        return h
    return g

from operator import add
make_adder = curry2(add)
x = make_adder(2)(3)
print(x)
