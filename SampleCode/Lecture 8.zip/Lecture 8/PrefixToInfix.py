class Stack:
    def __init__(self):
        self.items = []
    def isEmpty(self):
        return self.items == []
    def push(self, item):
        self.items.append(item)
    def pop(self):
        return self.items.pop()
    def peek(self):
        return self.items[len(self.items)-1]
    def size(self):
        return len(self.items)

def prefixToInfix(prefix):
	stack = Stack()
	# read prefix in reverse order
	i = len(prefix) - 1
	while i >= 0:
		if not isOperator(prefix[i]):
			# symbol is operand
			stack.push(prefix[i])
			i -= 1
		else:		
			# symbol is operator
			str = "(" + stack.pop() + prefix[i] + stack.pop() + ")"
			stack.push(str)
			i -= 1
	
	return stack.pop()

def isOperator(c):
    return c in "*+-/^()"

print(prefixToInfix("*-A/BC-/AKL"))
	
