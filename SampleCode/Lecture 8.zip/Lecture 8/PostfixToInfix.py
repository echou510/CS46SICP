def isOperand(x):
	return ((x >= 'a' and x <= 'z') or
			(x >= 'A' and x <= 'Z'))

def postfixToInfix(postfix) :
	s = []
	for i in range(len(postfix)):	
		# Insert at head
		if (isOperand(postfix[i])) :		
			s.insert(0, postfix[i])
		else:
			op1 = s[0]
			s.pop(0)
			op2 = s[0]
			s.pop(0)
			s.insert(0, "(" + op2 + postfix[i] + op1 + ")")
	return s[0]

print(postfixToInfix("ab-c+de*-"))


	
