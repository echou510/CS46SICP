def tree(label, branches=[]): 
    return [label]+ list(branches)

def label(tree): 
    return tree[0]

def branches(tree): 
    return tree[1:]

def is_leaf(tree): 
    return len(branches(tree)) == 0

def count_leaves(t): 
    if is_leaf(t): 
        return 1
    else: 
        leaves_under = 0 
        for b in branches(t): 
            leaves_under += count_leaves(b)
        return leaves_under

def count_leaves_sum(t): 
    if is_leaf(t): 
        return 1
    else: 
        leaves_unders = [count_leaves_sum(b) for b in branches(t)] 
        return sum(leaves_unders)

def copy(t): 
    if is_leaf(t): 
        return tree(label(t))
    else: 
        return tree(label(t), [tree(b) for b in branches(t)])

def print_tree(t, indent=0):
    print(indent*" ", label(t))
    for b in branches(t):
        print_tree(b, indent+3)


def sum_list(*args):
    s = []
    for alist in args: 
        s += alist
    return s

print(sum_list([1], [2, 3], [4]))

def leaves(t): 
    if is_leaf(t): return t
    else: 
        leaf_labels = [leaves(b) for b in branches(t)]
        return sum(leaf_labels, [])

t = tree(20, [tree(12, [tree(9, [tree(7), tree(2)]), tree(8, [tree(4), tree(4)])])])
print_tree(t)
print(leaves(t))

def count_paths(t, total): 
    if label(t) == total: 
        found = 1
    else: 
        found = 0 
    return found + sum([count_paths(b, total-label(t)) for b in branches(t)])
tx = tree(3, [tree(-1), tree(1, [tree(2, [tree(1)]), tree(3)]), tree(1, [tree(1)])])
print_tree(tx)
print(count_paths(tx, 3))
print(count_paths(tx, 4))
print(count_paths(tx, 5))
print(count_paths(tx, 6))
print(count_paths(tx, 7))