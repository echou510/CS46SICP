def fibo(n): 
    if n==0 or n==1: return 1
    return fibo(n-1)+fibo(n-2)

print(fibo(10))

def fibonacci(n): 
    if n==0 or n==1: return 1
    fn = 0   # f(i)
    fn1 =1    # f(i-1)
    fn2 =1    # f(i-2)
    i = 2
    while i<=n:  # i>n   
        fn = fn1 + fn2
        print("f(%d)=%d" % (i, fn))
        fn2 = fn1 
        fn1 = fn 
        i += 1

fibonacci(100)
