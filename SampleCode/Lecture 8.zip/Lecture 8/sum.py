def sum(a): 
    s = 0
    for x in a: 
        s += x
    return s 

def sumR(a): 
    if (len(a)==0): return 0
    return a[0]+sumR(a[1:])

def sumT(a):
    return sumHelper(a, 0, 0)

# Tail Recursion: 
#   It is recursive function that return the result from the previous calls
# without any more operations
def sumHelper(a, idx, s): # helper function for Tail Recursion
    if (idx>=len(a)): return s
    return sumHelper(a, idx+1, s+a[idx])


z = [3, 4, 7, 2]

print(sum(z))
print(sumR(z))
print(sumT(z))