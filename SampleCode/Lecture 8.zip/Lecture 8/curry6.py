def html_tag(tag_name, text):
	return "<" + tag_name + ">" + text + "</" + tag_name + ">"

import functools
p_tag = functools.partial(html_tag, "p")
x=p_tag("hello hello")

print(x)