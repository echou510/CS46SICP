# string3.py

a = "abcde"
b = "abcde"
c = "abccd"
e = "bbcde"
f = "ABCDE"
g = "abcdefgh"

alphabet = "".join([chr(x) for x in range(65, 91)])

def indexOf(string, pattern, start=0): 
    idx = 0
    try:
        idx = string.index(pattern, start)
    except: 
        idx = -1
    return idx

# alphanumeric by ASCII for comparison
print(a==b)  # System.out.println(a.equals(b)); 
print(a==c) 
print(a!=c)
print(a>c)   # True:  System.out.println(a.comparTo(c)>0); 
print(a>=c)  # True:  System.out.println(a.comparTo(c)>=0); 
print(a<c)   # False: System.out.println(a.comparTo(c)<0); 
print(a>f)   # True:  lowercase is greater than uppercase in ASCII code
print(a>g)   # Fasle: because g is longer

print(alphabet)

alpha2 = "-".join([chr(x) for x in range(97, 123)])
print(alpha2)

print("GHI" in alphabet)  # alphabet.contains("GHI")
print("ZZZ" in alphabet)
print(alphabet.index("GHI"))
#print(alphabet.index("ZZZ"))

source = "AABDBACDEDABAAABBABABAABBBBBAAAA"

ablist = []   # creating a list: array, arraylist
pos = indexOf(source, "AB")
while pos>0: 
    ablist.append(pos)
    pos = indexOf(source, "AB", pos+2)

print(ablist)