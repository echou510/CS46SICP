import numpy as np

# numpy array is really
# 1. mutable 
# 2. no change of length
# 3. slicing [s:e:st]
# 4. add scalar or vector to it. 
a = np.array([1, 2, 3, 4, 5])
print(a)

# vector + scalar 
b = a + 1 # vector processing 
print(b)
c = a * 3  # vector processing 
print(c)
d = c / 2 
print(d)

# vector + vector 
v = np.array([1, -1, 1, -1, 1])
u = a + v 
print(u)

x = list(a)
x.append(100)  # append does not return 
x = np.array(x)
print(x)

# Matrix operation on vectors. 
th30 = 30 * np.pi/180   # 30 degree in radian scale
M30 = np.array([[np.cos(th30), -np.sin(th30)],[np.sin(th30), np.cos(th30)]])

v = np.array([1, 0]).T
u = M30.dot(v)
print(u)