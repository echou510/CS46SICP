# tuple1.py
#  fixed size sequence - closer to Java array
#  tuples are immutable (no change)
#  fixed data vector (no change)

def swap(a, b): return (b, a)

def gcd(m, n):
    if (n==0): return m
    return gcd(n, m%n)

def gcf(m, n): 
    while n!=0: (m, n) = (n, m%n)
    return m

t = (1, 2, 3)

for i in range(len(t)):
    print(t[i])

#t.append(4)  # no, no no no. tuple is of fixes size
print(t[2])

#t[2]= 7
#print(t)

tx = (t[0], t[1], 7)
print(tx)

a = 3
b = 4
print("a=", a, "b=", b) 
(a, b) = swap(a, b)
print("a=", a, "b=", b) 

print(gcf(32, 48))
print(gcf(65, 78))