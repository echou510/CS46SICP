# string2.py
# slicing
#           01234567890123456789012345
alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
# - (nega) -65432109876543210987654321

# single character access you can use array indexing way to access it. 
print(alphabet[10])
#print(alphabet[27])   # it will cause index Out of bound problem. 
print(alphabet[-1])

# substring
# str.substring(1, 3)
# string[start:end:step]   start:start index, end: the end index (not included), step += 
alphasub = alphabet[1:3]
print(alphasub)
alphaeven = alphabet[0:26:2]
print(alphaeven)
alphaodd = alphabet[1:26:2]
print(alphaodd)
alphaD3 = alphabet[3:26:3]
print(alphaD3)
alpharev = alphabet[-1::-1]
print(alpharev)
alphalast5B = alphabet[-1:-6:-1]
print(alphalast5B)
alphalast5F = alphabet[-5::1]
print(alphalast5F)

# string[index] means a single character string.charAt(index)
# string[start:end] === string[start:end:1] 
# string[::]        === string[0:len(string):1]
alphanothing = alphabet[::]
print(alphanothing)
# string[:2:]       === string[0:2:1] === string[0:2]
alpha02 = alphabet[:2:]
print(alpha02)
# string[-3:-1]     === string[n-3:n-1] === string[n-3:n-1:1]
alphan3n1 = alphabet[-3:-1]
print(alphan3n1)
# string[-1:-3]     === string[n-1:n-3] === string[n-1:n-3:1]
alphan1n3 = alphabet[-1:-3]
print("**"+alphan1n3+"**")
alphan1n3 = alphabet[-1:-3:-1]
print("**"+alphan1n3+"**")
# string[-1:]  === string[n-1:n] === string[n-1:n:1]
alpharev = alphabet[-1:] 
print(alpharev)
alpharev2 = alphabet[-1::-2]
print(alpharev2)