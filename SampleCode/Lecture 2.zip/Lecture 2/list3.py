from pylab import *

def indexOf(alist, key):
    idx = -1
    try: idx = alist.index(key)
    except: pass
    return idx

a = [1, 2]
b = [3, 4]

print(a+b)  # concatenation 

c = [1, 2] * 3
print(c)    # duplication

"""
No -, no / for lists 
d = [1, 2, 3, 4, 5, 6, 1, 2]
e = d - a
print(e)
"""
d = [1, 2, 3, 4, 5, 6, 1, 2]
b1 = 6 in d 
print("6 in d is ", b1)
b2 = 15 in d 
print("15 in d is ", b2)

# aggregate function 
s = sum(d)
print("sum(d)=", s)
s = max(d)
print("max(d)=", s)
s = min(d)
print("min(d)=", s)

# sort: destructive sorting, d got changed
d.sort()   
print(d)

# sorted is non-destructive sorting, a new list sorted will be created
d = [1, 2, 3, 4, 5, 6, 1, 2]
f = sorted(d)
print("d[]=", d)
print("f[]=", f)

d = [1, 3, 5, 6, 7, 8, 10]
i = indexOf(d, 7)
print("7 is at index %3d" % i)  # similar to System.out.printf(); 
i = indexOf(d, 4)
print("4 is at inddex %d" % i)