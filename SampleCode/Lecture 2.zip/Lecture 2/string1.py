# string1.py

alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

print(type(alphabet))
print(len(alphabet))              # Java's alphabet.length()
print(alphabet[9])                # Java alphabet.charAt(9) 
print(alphabet.lower())           # alphabet.toLowerCase()
print(alphabet.index("GHI"))      # alphabet.indexOf("GHI")

ch = alphabet[5]
asc = ord(ch)
print(ord(ch))                    # ascii code of the character
print(chr(asc))                   # char of the ascii code

yesLetter = ch.isalpha()           # check if ch is a letter or not
print(yesLetter)                   # Character.isLetter(ch)
yesDigit = ch.isdigit()            # Character.isDigit(ch)
print(yesDigit)
yesLetterOrNumber = ch.isalnum()   # Character.isLetterOrDigit(ch)
print(yesLetterOrNumber)