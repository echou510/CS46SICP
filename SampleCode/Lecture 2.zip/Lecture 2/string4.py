# string4.py
#  formatted strings
points = [(1, 2), (3,4), (-1, 2), (5, 1), (1, -4)]

for p in points: 
    s = "Point(%d, %d)" % p
    print(s)

name = "Eric"
age = 15
score = 10
s1 = (name, age, score)
print("Student: %s, Age:%d, Score:%d" % (name, age, score))
print("Student: %s, Age:%d, Score:%d" % s1)

f = 98 
c = (f-32)/1.8
print("%.2fF is %.2fC" % (f, c))