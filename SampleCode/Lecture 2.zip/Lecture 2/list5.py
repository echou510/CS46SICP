a = ["I", "am", "a", "good", "student", "from", "Washington", "high", "school"]
first = [word[0] for word in a]
s = "".join(first)
print(s)

print("".join([word[0] for word in ["I", "am", "a", "good", "student", "from", "Washington", "high", "school"]]))

last = [word[-1] for word in a]
s ="".join(last)
print(s)
middle = [word[len(word)//2] for word in a]
s = "".join(middle)
print(s) 