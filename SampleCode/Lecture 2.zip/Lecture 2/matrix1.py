from pylab import *
from pprint import *  # pretty print 
m =[
    [1, 2, 3], 
    [4, 5, 6], 
    [7, 8, 9]
]

print(m)
pprint(m)

for row in m: 
    for x in row: 
        print(x, end=" ")
    print()
print()
print()

for i in range(len(m)): 
    for j in range(len(m[i])): 
        print(m[i][j], end=" ")
    print() 
print()
print()