a = ['a', 'c', 'e']
print(a)

s = "".join(a)
print(s)

a2 = list(s)
print(a2)

b = ["I", 'Love', "You"]
punc ="."
question = "?"
s2 = " ".join(b)
s3 = s2+punc
print(s3)
s4 = s2+question
print(s4)

b2 = s2.split(" ")
print(b2)