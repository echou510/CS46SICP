# list2.py
#   vector in C++, arraylist in Java, same as array? no no no
#   list is dynamic, flexible
from random import *
import numpy as np

# exmaple list
a = [1, 2, 3]
print(a)

# Comprehesion list
b = [x**2 for x in range(1, 4)]
print(b)

# loop for list create
c = []
for i in range(len(a)):
    z = a[i]-2
    c.append(z) 

print(c)

d = [0 for i in range(10)]
for i in range(10): 
    d[i] = randint(1, 10)   # from 1, to 10 (included)
print(d)

e = list(np.zeros(10))   # np.zeros(10) create 10 element 0 array
print(e)
