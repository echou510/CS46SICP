# set:
# non-recurring 
# { }

s = {4, 3, 1} | {3}  # empty set union with {3}  equivalent to add 3 to s
print(s)

s = {1, 2, 3, 4, 5}
t = {2, 4}

print(s | t)   # union
print(s & t)   # intersect
print(s - t)   # set difference

slist = list(s)
print(slist)
ss = set(slist)
print(ss)

a = [1, 2, 3, 3, 1, 2, 1, 3, 1, 1, 2, 4, 5, 6]
s = set(a)
print(s)
a = list(s)
print(a)