# comprehension list
from pylab import *
import numpy as np

a = np.linspace(0, 10, 11) # creating sample 
#a = [1, 2, 4, 8, 16] 
asq = [x**2 for x in a]
acube = [x**3 for x in a]
print(a)
print(asq)
figure()
bar(a, asq, color=(1.0, 0, 0, 1)) # R G B  
show()

figure()
bar(a, acube, color=(0, 0.5, 0.5, 1)) # R G B 
show()