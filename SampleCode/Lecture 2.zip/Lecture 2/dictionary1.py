from pprint import *
student = {
  'name': 'eric', 
  'age': 15, 
  'score': 10
}

print(student)

slist = [student, student, student]
pprint(slist)

dd = dict()
pprint(dd)
dd['key'] = "a tool to open door"
dd['cup'] = "a tool to drink water"
dd['money'] = "a tool to price things"
pprint(dd)

dd['subject'] = ['math', 'english', 'science']
dd['score'] = [10, 10, 10]
pprint(dd)

ascii = dict()

for ch in "".join([chr(x) for x in range(65, 91)]): 
    ascii[ch] = ord(ch)

print(ascii)

# ascii.items create a list of tuple of (key, value)
for item in ascii.items(): 
    print(item)

# ascii.keys create a list of keys
for key in ascii.keys(): 
    print(key)

# ascii.values create a list of values
for v in ascii.values(): 
    print(v)

# get each property
for k in ascii: 
    print("%s - %d" % (k, ascii[k]))
